#!/usr/bin/env python3
"""Fetch pinned inputs, reconstruct exact sources, build, and replay.

Only files inside --work are written. No archived private evidence is required.
The prepare/check steps do not invoke Lean. See README.txt for prerequisites.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
MANIFEST = json.loads((ROOT / 'sources.json').read_text())
TOOLS = {
    'comparator': ('https://github.com/leanprover/comparator.git',
                  'd03acab154d269c06e60e4de7e4cc85deebff94b'),
    'lean4export': ('https://github.com/leanprover/lean4export.git',
                    '076e8e57707e813375e8f9da8bf989799ace9680'),
    'landrun': ('https://github.com/Zouuup/landrun.git',
                '811cfff51ceaf3d9843708aa6d22e9b84ccac8b4'),
}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def run(args, cwd=None, env=None, capture=False):
    return subprocess.run([str(a) for a in args], cwd=cwd, env=env,
                          check=True, text=True,
                          stdout=subprocess.PIPE if capture else None).stdout

def verify_revision(path, expected):
    actual = run(['git', '-C', path, 'rev-parse', 'HEAD'], capture=True).strip()
    if actual != expected:
        raise RuntimeError(f'Unexpected revision for {path.name}: {actual}')

def checkout(url, revision, path):
    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        run(['git', 'init', path])
        run(['git', '-C', path, 'remote', 'add', 'origin', url])
        run(['git', '-C', path, '-c', 'core.hooksPath=/dev/null',
             'fetch', '--depth=1', 'origin', revision])
        run(['git', '-C', path, '-c', 'core.hooksPath=/dev/null',
             'checkout', '--detach', 'FETCH_HEAD'])
    verify_revision(path, revision)

def put(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_bytes() != data:
        raise RuntimeError(f'Refusing to replace different existing file: {path.name}')
    path.write_bytes(data)

def check_bytes(data, expected, label):
    if sha(data) != expected:
        raise RuntimeError(f'SHA-256 mismatch: {label}')

def fetch(work):
    for name, info in MANIFEST['upstreams'].items():
        checkout(info['url'], info['revision'], work / 'upstream' / name)

def prepare(work, openai=None, liu=None):
    upstreams = {'openai': openai or work / 'upstream/openai',
                 'liu': liu or work / 'upstream/liu'}
    for name, path in upstreams.items():
        verify_revision(path, MANIFEST['upstreams'][name]['revision'])
    project = work / 'project'
    for entry in MANIFEST['baseline']:
        data = (upstreams['openai'] / entry['upstream_path']).read_bytes()
        check_bytes(data, entry['sha256'], entry['module'])
        put(project / entry['target'], data)
    for entry in MANIFEST['extension']:
        if 'file' in entry:
            data = (ROOT / entry['file']).read_bytes()
        else:
            recipe = json.loads((ROOT / entry['recipe']).read_text())
            source = (upstreams[recipe['upstream']] / recipe['path']).read_bytes()
            check_bytes(source, recipe['source_sha256'], recipe['path'])
            text = source.decode('utf-8')
            data = ''.join(text[op['copy_characters'][0]:op['copy_characters'][1]]
                           if 'copy_characters' in op else op['insert']
                           for op in recipe['operations']).encode('utf-8')
            check_bytes(data, recipe['target_sha256'], entry['module'])
        check_bytes(data, entry['sha256'], entry['module'])
        put(project / entry['target'], data)
    for name in ['lakefile.lean', 'lake-manifest.json', 'lean-toolchain', 'LICENSE']:
        put(project / name, (ROOT / 'config' / name).read_bytes())
    for name in ['V4Challenge.lean', 'ReplayCandidate.lean', 'candidate-comparator.json']:
        put(work / 'audit' / name, (ROOT / 'audit' / name).read_bytes())
    check(work)

def check(work):
    project = work / 'project'
    for entry in MANIFEST['baseline'] + MANIFEST['extension']:
        check_bytes((project / entry['target']).read_bytes(), entry['sha256'], entry['module'])
    extension = {e['module']: e for e in MANIFEST['extension']}
    seen = set()
    for module in MANIFEST['build_order']:
        if module in seen:
            raise RuntimeError('Duplicate module in build order')
        if any(dep in extension and dep not in seen for dep in extension[module]['imports']):
            raise RuntimeError(f'Invalid build order at {module}')
        seen.add(module)
    if seen != set(extension):
        raise RuntimeError('Incomplete build order')
    print('SOURCE_CHECK_SUCCESS: 2,924 baseline + 248 extension sources match pinned hashes; build order is valid.')

def dependencies(work):
    project = work / 'project'
    manifest = json.loads((project / 'lake-manifest.json').read_text())
    for package in manifest['packages']:
        if package['type'] != 'git':
            raise RuntimeError('Unexpected non-Git dependency')
        name = package['name'].strip('«»')
        checkout(package['url'], package['rev'], project / '.lake/packages' / name)
    for name in ['rellich-kondrachov', 'PrimeNumberTheoremAnd']:
        dep = project / '.lake/packages' / name
        patch = ROOT / 'patches' / (name + '-lean4341.patch')
        test = subprocess.run(['git', '-C', str(dep), 'apply', '--reverse', '--check', str(patch)],
                              stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if test.returncode != 0:
            run(['git', '-C', dep, 'apply', '--check', patch])
            run(['git', '-C', dep, 'apply', patch])
    print('Pinned dependencies fetched; the two upstream compatibility patches are present.')

def lean_environment(work):
    project = work / 'project'
    version = run(['lean', '--version'], cwd=project, capture=True)
    if 'version 4.34.1' not in version:
        raise RuntimeError('Lean 4.34.1 is required: ' + version)
    env = os.environ.copy()
    env['LEAN_NUM_THREADS'] = '4'
    return env

def build(work):
    check(work)
    project = work / 'project'
    env = lean_environment(work)
    # An official Mathlib cache is allowed; it is part of the recorded trust scope.
    run(['lake', 'exe', 'cache', 'get'], cwd=project, env=env)
    run(['lake', 'build', 'OAI'], cwd=project, env=env)
    env['PUBLIC_PROOF_ROOT'] = str(project / 'proof')
    for module in MANIFEST['build_order']:
        print('Checking', module, flush=True)
        run(['lake', 'env', 'bash', '-c',
             'export LEAN_PATH="$PUBLIC_PROOF_ROOT:$LEAN_PATH"; '
             'exec lean -j 4 --root="$PUBLIC_PROOF_ROOT" '
             '-o "$PUBLIC_PROOF_ROOT/$1.olean" "$PUBLIC_PROOF_ROOT/$1.lean"',
             '--', module], cwd=project, env=env)
    check(work)
    print('FULL_BUILD_SUCCESS. Comparator replay is a separate step.')

def tools(work):
    for name in ['comparator', 'landrun']:
        checkout(*TOOLS[name], work / 'tools' / name)
    comparator = work / 'tools/comparator'
    checkout(*TOOLS['lean4export'], comparator / '.lake/packages/lean4export')
    # Match the previously tested toolchain/dependency pins, without changing verifier logic.
    (comparator / 'lean-toolchain').write_text('leanprover/lean4:v4.34.1\n')
    config = comparator / 'lakefile.toml'
    config.write_text(config.read_text().replace('rev = "master"',
                       'rev = "' + TOOLS['lean4export'][1] + '"'))
    lock = comparator / 'lake-manifest.json'
    obj = json.loads(lock.read_text())
    for package in obj['packages']:
        if package['name'] == 'lean4export':
            package['rev'] = TOOLS['lean4export'][1]
            package['inputRev'] = TOOLS['lean4export'][1]
    lock.write_text(json.dumps(obj, indent=2) + '\n')
    env = lean_environment(work)
    run(['lake', 'build', 'lean4export', 'comparator'], cwd=comparator, env=env)
    run(['go', 'build', '-o', 'landrun', '.'], cwd=work / 'tools/landrun', env=env)

def replay(work):
    check(work)
    env = lean_environment(work)
    env['PUBLIC_PROOF_WORK'] = str(work)
    run(['bash', ROOT / 'replay.sh'], cwd=work / 'project', env=env)
    check(work)

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('command', choices=['fetch', 'prepare', 'check', 'dependencies', 'build', 'tools', 'replay'])
    p.add_argument('--work', type=Path, default=ROOT / 'build-work')
    p.add_argument('--openai', type=Path, help='Already fetched pinned OpenAI checkout, for prepare')
    p.add_argument('--liu', type=Path, help='Already fetched pinned Liu checkout, for prepare')
    args = p.parse_args()
    work = args.work.resolve()
    work.mkdir(parents=True, exist_ok=True)
    if args.command == 'prepare':
        prepare(work, args.openai, args.liu)
    else:
        globals()[args.command](work)

if __name__ == '__main__':
    main()
