import KappaCountStability
import OAI.NumberTheory.DirichletL.Hecke.DetectorRowCountOptimization

namespace QRHExtension.KappaCounts
noncomputable section
open QRHExtension.KappaOptimization

abbrev denominator := QRHExtension.KappaOptimization.countD
abbrev primeWeight := QRHExtension.KappaOptimization.primeWeight
abbrev inverseExponent := OAI.SevenEighths.HeckeDetectorRowCount.inverseExponent
abbrev longExponent := OAI.SevenEighths.HeckeDetectorRowCount.longExponent

def crossing (κ x t : ℝ) : ℝ :=
  (countA κ x*t-x+x/(3*κ))/denominator κ x
def plainExponent (κ δ x t r : ℝ) : ℝ :=
  1-δ*(x/(3*κ)+countA κ x*(t-r))
def shortExponent (κ δ x t : ℝ) : ℝ :=
  1-δ+δ*primeWeight κ x/denominator κ x*(3/2-t)
def balancedCutoff (κ δ x : ℝ) : ℝ :=
  1+δ*primeWeight κ x/(2*countJ κ δ x)

lemma denominator_lower {κ x : ℝ} (hk : 2/3 ≤ κ)
    (hx : 0 ≤ x) (hx' : x ≤ 1/2) : 2 ≤ denominator κ x :=
  (generalized_count_geometry κ x hk hx hx').2.1

theorem crossing_bounds {κ x t : ℝ} (hk : 2/3 ≤ κ) (hk' : κ ≤ 3/4)
    (hx : 0 ≤ x) (hx' : x ≤ 1/2) (ht : 1 ≤ t) (ht' : t ≤ 3/2) :
    23/37 ≤ crossing κ x t ∧ crossing κ x t ≤ 1 ∧
      1/3 ≤ t-crossing κ x t ∧ t-crossing κ x t ≤ 1/2 := by
  let c := x/(3*κ)
  have hkp : 0 < 3*κ := by linarith
  have hc : 0 ≤ c := div_nonneg hx hkp.le
  have hcmax : c ≤ x/2 := by
    apply (div_le_iff₀ hkp).2
    nlinarith [mul_le_mul_of_nonneg_right hk hx]
  have hcmin : 4*x/9 ≤ c := by
    apply (le_div_iff₀ hkp).2
    nlinarith [mul_le_mul_of_nonneg_right hk' hx]
  have hd : 0 < 3-x-2*c := by linarith
  have ha : 0 ≤ 2-2*c := by linarith
  have hat := mul_le_mul_of_nonneg_left ht ha
  have hat' := mul_le_mul_of_nonneg_left ht' ha
  have hmx : 0 ≤ 1-x := by linarith
  have hmt := mul_le_mul_of_nonneg_left ht hmx
  have hmt' := mul_le_mul_of_nonneg_left ht' hmx
  have hcross : crossing κ x t=((2-2*c)*t-x+c)/(3-x-2*c) := by
    unfold crossing denominator countD countA
    dsimp [c]
    ring
  have hm : t-crossing κ x t=((1-x)*t+x-c)/(3-x-2*c) := by
    rw [hcross]
    apply (eq_div_iff hd.ne').2
    rw [sub_mul,div_mul_cancel₀ _ hd.ne']
    ring
  refine ⟨?_,?_,?_,?_⟩
  · rw [hcross]
    apply (le_div_iff₀ hd).2
    nlinarith
  · rw [hcross]
    apply (div_le_iff₀ hd).2
    nlinarith
  · rw [hm]
    apply (le_div_iff₀ hd).2
    nlinarith
  · rw [hm]
    apply (div_le_iff₀ hd).2
    nlinarith

theorem crossing_average (κ δ x t r : ℝ) (hk : κ ≠ 0)
    (hd : denominator κ x ≠ 0) :
    (countA κ x*inverseExponent δ x r+(1-x)*plainExponent κ δ x t r)/
        denominator κ x = shortExponent κ δ x t := by
  simp only [inverseExponent, OAI.SevenEighths.HeckeDetectorRowCount.inverseExponent,
    plainExponent, shortExponent, primeWeight, QRHExtension.KappaOptimization.primeWeight]
  field_simp [hd]
  simp only [denominator, countD, countA]
  field_simp [hk]
  ring

lemma inverse_at_crossing (κ δ x t : ℝ) (hk : κ ≠ 0)
    (hd : denominator κ x ≠ 0) :
    inverseExponent δ x (crossing κ x t)=shortExponent κ δ x t := by
  simp only [inverseExponent, OAI.SevenEighths.HeckeDetectorRowCount.inverseExponent,
    crossing, shortExponent, primeWeight, QRHExtension.KappaOptimization.primeWeight]
  field_simp [hd]
  simp only [denominator, countD, countA]
  field_simp [hk]
  ring

lemma plain_at_crossing (κ δ x t : ℝ) (hk : κ ≠ 0)
    (hd : denominator κ x ≠ 0) :
    plainExponent κ δ x t (crossing κ x t)=shortExponent κ δ x t := by
  simp only [plainExponent, crossing, shortExponent, primeWeight,
    QRHExtension.KappaOptimization.primeWeight]
  field_simp [hd]
  simp only [denominator, countD, countA]
  field_simp [hk]
  ring

theorem selected_short_bound {κ δ x t r : ℝ} (hk : 2/3 ≤ κ)
    (hδ : 0 ≤ δ) (hx : 0 ≤ x) (hx' : x ≤ 1/2) :
    (r ≤ crossing κ x t → plainExponent κ δ x t r ≤ shortExponent κ δ x t) ∧
      (crossing κ x t ≤ r → inverseExponent δ x r ≤ shortExponent κ δ x t) := by
  obtain ⟨hA,hD,hP⟩ := generalized_count_geometry κ x hk hx hx'
  have hkp : κ ≠ 0 := ne_of_gt (by linarith)
  have hd : denominator κ x ≠ 0 := ne_of_gt (by linarith)
  constructor
  · intro hr
    rw [← plain_at_crossing κ δ x t hkp hd]
    unfold plainExponent
    have hh := mul_le_mul_of_nonneg_left hr (show 0 ≤ countA κ x by linarith)
    nlinarith [mul_nonneg hδ (sub_nonneg.mpr hh)]
  · intro hr
    rw [← inverse_at_crossing κ δ x t hkp hd]
    simp only [inverseExponent, OAI.SevenEighths.HeckeDetectorRowCount.inverseExponent]
    have hh := mul_le_mul_of_nonneg_left hr (show 0 ≤ 1-x by linarith)
    nlinarith [mul_nonneg hδ (sub_nonneg.mpr hh)]

lemma plain_capacity_bound {m κ : ℝ} (hm : 1/3 ≤ m) (hm' : m ≤ 1/2)
    (hk : 2/3 ≤ κ) : 0 ≤ (1-2*m)/(6*κ) ∧ (1-2*m)/(6*κ) ≤ 1/12 := by
  have hkp : 0 < 6*κ := by linarith
  constructor
  · exact div_nonneg (by linarith) hkp.le
  · apply (div_le_iff₀ hkp).2
    nlinarith

lemma short_ge_base {κ δ x t : ℝ} (hk : 2/3 ≤ κ)
    (hδ : 0 ≤ δ) (hx : 0 ≤ x) (hx' : x ≤ 1/2) (ht : t ≤ 3/2) :
    1-δ ≤ shortExponent κ δ x t := by
  obtain ⟨hA,hD,hP⟩ := generalized_count_geometry κ x hk hx hx'
  have hd : 0 < denominator κ x := by linarith
  have hp : 0 ≤ primeWeight κ x := by linarith
  unfold shortExponent
  exact le_add_of_nonneg_right
    (mul_nonneg (div_nonneg (mul_nonneg hδ hp) hd.le) (by linarith))

theorem plain_capacity_comparison {κ δ x t r m γ : ℝ}
    (hk : 2/3 ≤ κ) (hδ : 0 ≤ δ) (hδ' : δ ≤ 1)
    (hx : 0 ≤ x) (hx' : x ≤ 1/2) (hγ : 0 ≤ γ)
    (hlength : t-r-γ ≤ m) :
    1-2*δ*m-2*(δ*x)*(1-2*m)/(6*κ) ≤ plainExponent κ δ x t r+2*γ := by
  have hkp : κ ≠ 0 := ne_of_gt (by linarith)
  have hA := (generalized_count_geometry κ x hk hx hx').1
  have hAu : countA κ x ≤ 2 := by
    unfold countA
    have hh : 0 ≤ 2*x/(3*κ) := div_nonneg (by linarith) (by linarith)
    linarith
  have hc : 0 ≤ δ*countA κ x := mul_nonneg hδ (by linarith)
  have hcu : δ*countA κ x ≤ 2 := by
    have hh := mul_le_mul_of_nonneg_right hδ' (show 0 ≤ countA κ x by linarith)
    nlinarith
  have hlinear := mul_le_mul_of_nonneg_left (show t-r-m ≤ γ by linarith) hc
  have herror := mul_le_mul_of_nonneg_right hcu hγ
  have hid : (1-2*δ*m-2*(δ*x)*(1-2*m)/(6*κ))-plainExponent κ δ x t r =
      δ*countA κ x*(t-r-m) := by
    unfold plainExponent countA
    field_simp [hkp]
    ring
  linarith

theorem balanced_cutoff_bounds {κ δ x : ℝ} (hk : 2/3 ≤ κ)
    (hδ : 0 ≤ δ) (hδ' : δ ≤ 5/6) (hx : 0 ≤ x) (hx' : x ≤ 1/2) :
    1 ≤ balancedCutoff κ δ x ∧ balancedCutoff κ δ x ≤ 3/2 := by
  obtain ⟨hJ,hJs⟩ := generalized_countJ_bounds κ δ x hk hδ hδ' hx hx'
  obtain ⟨hA,hD,hP⟩ := generalized_count_geometry κ x hk hx hx'
  have hp : 0 ≤ δ*primeWeight κ x := mul_nonneg hδ (by linarith)
  have hle : δ*primeWeight κ x ≤ countJ κ δ x := by
    have hh := mul_nonneg (show 0 ≤ 5/6-δ by linarith)
      (show 0 ≤ countD κ x by linarith)
    unfold countJ
    linarith
  have hr0 : 0 ≤ δ*primeWeight κ x/(2*countJ κ δ x) := div_nonneg hp (by positivity)
  have hr1 : δ*primeWeight κ x/(2*countJ κ δ x) ≤ 1/2 :=
    (div_le_iff₀ (by positivity)).2 (by linarith)
  unfold balancedCutoff
  constructor <;> linarith

theorem balanced_values (κ δ x : ℝ) (hk : κ ≠ 0)
    (hd : denominator κ x ≠ 0) (hJ : countJ κ δ x ≠ 0) :
    shortExponent κ δ x (balancedCutoff κ δ x)=
      longExponent δ (balancedCutoff κ δ x) := by
  simp only [shortExponent, longExponent, OAI.SevenEighths.HeckeDetectorRowCount.longExponent,
    balancedCutoff]
  field_simp [hd,hJ]
  simp only [countJ, denominator, countD, primeWeight, QRHExtension.KappaOptimization.primeWeight, countA]
  field_simp [hk]
  ring

theorem balanced_count_identity {κ δ x : ℝ} (hk : 2/3 ≤ κ)
    (hδ : 0 ≤ δ) (hδ' : δ ≤ 5/6) (hx : 0 ≤ x) (hx' : x ≤ 1/2) :
    max (shortExponent κ δ x (balancedCutoff κ δ x))
      (longExponent δ (balancedCutoff κ δ x)) = countR κ δ x := by
  have hD := denominator_lower hk hx hx'
  have hJ := (generalized_countJ_bounds κ δ x hk hδ hδ' hx hx').1
  have hb := balanced_values κ δ x (ne_of_gt (by linarith))
    (ne_of_gt (by linarith)) hJ.ne'
  rw [hb,max_self]
  simp only [longExponent, OAI.SevenEighths.HeckeDetectorRowCount.longExponent,
    balancedCutoff, countR]
  ring

theorem count_bound_of_source_branches (B C U κ δ x t r m ε ν γ : ℝ)
    (hC : 0 ≤ C) (hU : 1 ≤ U) (hk : 2/3 ≤ κ) (hk' : κ ≤ 3/4)
    (hδ : 0 ≤ δ) (hδ' : δ ≤ 5/6) (hx : 0 ≤ x) (hx' : x ≤ 1/2)
    (ht : 1 ≤ t) (ht' : t ≤ 3/2) (hν : 0 ≤ ν) (hγ : 0 ≤ γ)
    (hleft : t-r-γ ≤ m) (hright : r ≤ t+γ)
    (hI0 : B ≤ C*U^(max 1 ((1+5*r)/6)-δ*r+ε))
    (hP0 : B ≤ C*U^(1-2*δ*m+ε))
    (hI : 23/37 ≤ r → r < 1 → ν < (1-r)/2 → B ≤ C*U^(inverseExponent δ x r+ε))
    (hP : r ≤ crossing κ x t → m < 1/2 → ν < (1-2*m)/(6*κ) →
      B ≤ C*U^(1-2*δ*m-2*(δ*x)*(1-2*m)/(6*κ)+ε)) :
    B ≤ C*U^(max (shortExponent κ δ x t) (longExponent δ t)+ε+6*ν+3*γ) := by
  let target := max (shortExponent κ δ x t) (longExponent δ t)+ε+6*ν+3*γ
  have hshort : shortExponent κ δ x t ≤ max (shortExponent κ δ x t) (longExponent δ t) := le_max_left _ _
  have hlong : longExponent δ t ≤ max (shortExponent κ δ x t) (longExponent δ t) := le_max_right _ _
  have hbase := short_ge_base hk hδ hx hx' ht'
  have hcross := crossing_bounds hk hk' hx hx' ht ht'
  have hchoose := selected_short_bound (t:=t) (r:=r) hk hδ hx hx'
  have promote (p : ℝ) (hp : B ≤ C*U^p) (hpt : p ≤ target) : B ≤ C*U^target :=
    hp.trans (mul_le_mul_of_nonneg_left (Real.rpow_le_rpow_of_exponent_le hU hpt) hC)
  by_cases hr1 : 1 ≤ r
  · have hmax : max 1 ((1+5*r)/6)=(1+5*r)/6 := max_eq_right (by linarith)
    rw [hmax] at hI0
    apply promote _ hI0
    have hl := OAI.SevenEighths.HeckeDetectorRowCount.long_count_bound hδ' hγ hright
    have hcγ : (5/6-δ)*γ ≤ γ := by nlinarith [mul_nonneg hδ hγ]
    dsimp [target]
    nlinarith
  have hr1' : r < 1 := lt_of_not_ge hr1
  have hmax : max 1 ((1+5*r)/6)=1 := max_eq_left (by linarith)
  rw [hmax] at hI0
  by_cases hrc : crossing κ x t ≤ r
  · by_cases hcap : (1-r)/2 ≤ ν
    · apply promote _ hI0
      have hz := OAI.SevenEighths.HeckeDetectorRowCount.inverse_zero_capacity hδ hcap
      have hv : 2*δ*ν ≤ 6*ν := by nlinarith [mul_nonneg (sub_nonneg.mpr hδ') hν]
      dsimp [target]
      linarith
    · apply promote _ (hI (hcross.1.trans hrc) hr1' (lt_of_not_ge hcap))
      have hs := hchoose.2 hrc
      dsimp [target]
      linarith
  have hrc' : r ≤ crossing κ x t := (lt_of_not_ge hrc).le
  by_cases hm : 1/2 ≤ m
  · apply promote _ hP0
    have hm' := mul_le_mul_of_nonneg_left hm hδ
    dsimp [target]
    linarith
  have hm' : m < 1/2 := lt_of_not_ge hm
  by_cases hcap : (1-2*m)/(6*κ) ≤ ν
  · apply promote _ hP0
    have hz := OAI.SevenEighths.HeckeDetectorRowCount.plain_zero_capacity hδ
      (show 0 < κ by linarith) (show κ ≤ 1 by linarith) hν hcap
    have hv : 6*δ*ν ≤ 6*ν := by nlinarith [mul_nonneg (sub_nonneg.mpr hδ') hν]
    dsimp [target]
    linarith
  · apply promote _ (hP hrc' hm' (lt_of_not_ge hcap))
    have hp := plain_capacity_comparison hk hδ (show δ ≤ 1 by linarith)
      hx hx' hγ hleft
    have hs := hchoose.1 hrc'
    dsimp [target]
    linarith

#print axioms crossing_bounds
#print axioms balanced_count_identity
#print axioms plain_capacity_comparison
#print axioms count_bound_of_source_branches
end
end QRHExtension.KappaCounts
