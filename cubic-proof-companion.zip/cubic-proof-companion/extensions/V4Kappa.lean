import V4Geometry
import ExistingBoundary

namespace RHV4
noncomputable section
open OAI.SevenEighths

/-- The source construction uses one parameter for all finite analytic inputs. -/
def globalGap : ℝ := max 0 (HeckeZeroSupremum.beta-boundary)
def kappaActual : ℝ := kappa0+2*globalGap

theorem globalGap_nonneg : 0≤globalGap := le_max_left _ _
theorem kappaActual_base : kappa0≤kappaActual := by
  unfold kappaActual
  linarith [globalGap_nonneg]
theorem kappaActual_lower : (13/18:ℝ)≤kappaActual :=
  kappa0_lower.trans kappaActual_base

theorem kappaActual_upper : kappaActual≤(3/4:ℝ) := by
  have hb := QRHExtension.PreviousBoundary.beta_le_verified
  have hB := QRHExtension.KappaMethodLimit.methodLimit_bracket
  have hg : globalGap≤(87499/100000:ℝ)-boundary := by
    unfold globalGap
    apply max_le
    · rw [boundary_value]
      linarith [hB.2]
    · linarith
  change (2*boundary-1)+2*globalGap≤(3/4:ℝ)
  linarith

theorem kappaActual_beta : 2*HeckeZeroSupremum.beta-1≤kappaActual := by
  have hg : HeckeZeroSupremum.beta-boundary≤globalGap := le_max_right _ _
  change 2*HeckeZeroSupremum.beta-1≤(2*boundary-1)+2*globalGap
  linarith

theorem kappaActual_eq {beta : ℝ} (heq : beta=HeckeZeroSupremum.beta)
    (hbeta : boundary≤beta) : kappaActual=kappa0+2*(beta-boundary) := by
  subst beta
  unfold kappaActual globalGap
  rw [max_eq_right (sub_nonneg.mpr hbeta)]

/-- Under contradiction, capacity equals exactly the zero-supremum requirement. -/
theorem kappaActual_eq_twice_beta_sub_one (hbeta : boundary≤HeckeZeroSupremum.beta) :
    kappaActual=2*HeckeZeroSupremum.beta-1 := by
  rw [kappaActual_eq rfl hbeta]
  change (2*boundary-1)+2*(HeckeZeroSupremum.beta-boundary)=_
  ring

end
end RHV4
