import KappaCountOptimization
import Mathlib.Topology.Order.IntermediateValue

/-! Exact obstruction for three explicit scalar majorants with kappa>=2B-1.
This does not assert that those majorants are necessary for every possible
analytic proof. Nor does attainment of the three faces prove all-bin sufficiency.
The separate rational certificate supplies strict all-bin sufficiency nearby. -/
namespace QRHExtension.KappaMethodLimit
noncomputable section
open QRHExtension.KappaOptimization

def boundaryPolynomial (B : ℝ) : ℝ :=
  7884*B^3-18819*B^2+14643*B-3686

def criticalDelta (B : ℝ) : ℝ := (9*B-7)/(18*(1-B))
def lowFace (M ell : ℝ) : ℝ := 5/6+M/12-ell/6
def reflectedFace (M ell : ℝ) : ℝ := 1/3+7*M/12+ell/3
def highFace (δ M ell : ℝ) : ℝ := 1+δ-(1+δ)*M/2+δ*ell

theorem polynomial_strict_decrease {x y : ℝ}
    (hxl : 5/6 ≤ x) (hxu : x ≤ 7/8)
    (hyl : 5/6 ≤ y) (hyu : y ≤ 7/8) (hxy : x < y) :
    boundaryPolynomial y < boundaryPolynomial x := by
  let q := 7884*(x^2+x*y+y^2)-18819*(x+y)+14643
  have h1 : 0 ≤ 7884*(x+7/8+y)-18819 := by linarith
  have h2 : 0 ≤ 7884*(y+2*(7/8))-18819 := by linarith
  have hm1 := mul_nonpos_of_nonpos_of_nonneg (show x-7/8 ≤ 0 by linarith) h1
  have hm2 := mul_nonpos_of_nonpos_of_nonneg (show y-7/8 ≤ 0 by linarith) h2
  have hid : q+2907/16 =
      (x-7/8)*(7884*(x+7/8+y)-18819)+
      (y-7/8)*(7884*(y+2*(7/8))-18819) := by dsimp [q]; ring
  have hq : q < 0 := by linarith
  have hdiff : boundaryPolynomial y-boundaryPolynomial x=(y-x)*q := by
    unfold boundaryPolynomial
    dsimp [q]
    ring
  have hh := mul_neg_of_pos_of_neg (sub_pos.mpr hxy) hq
  linarith

theorem exists_method_limit :
    ∃ B : ℝ, B ∈ Set.Icc (5/6) (7/8) ∧ boundaryPolynomial B=0 := by
  have hc : Continuous boundaryPolynomial := by unfold boundaryPolynomial; fun_prop
  have hz : (0:ℝ) ∈ Set.Icc (boundaryPolynomial (7/8))
      (boundaryPolynomial (5/6)) := by norm_num [boundaryPolynomial]
  obtain ⟨B,hB,hzero⟩ := intermediate_value_Icc'
    (show (5/6:ℝ) ≤ 7/8 by norm_num) hc.continuousOn hz
  exact ⟨B,hB,hzero⟩

def methodLimit : ℝ := Classical.choose exists_method_limit

theorem methodLimit_spec :
    methodLimit ∈ Set.Icc (5/6) (7/8) ∧ boundaryPolynomial methodLimit=0 :=
  Classical.choose_spec exists_method_limit

theorem methodLimit_unique (B : ℝ) (hB : B ∈ Set.Icc (5/6) (7/8))
    (hzero : boundaryPolynomial B=0) : B=methodLimit := by
  obtain ⟨hR,hRzero⟩ := methodLimit_spec
  rcases lt_trichotomy B methodLimit with h|h|h
  · have hh := polynomial_strict_decrease hB.1 hB.2 hR.1 hR.2 h
    rw [hzero,hRzero] at hh
    linarith
  · exact h
  · have hh := polynomial_strict_decrease hR.1 hR.2 hB.1 hB.2 h
    rw [hzero,hRzero] at hh
    linarith

theorem methodLimit_bracket :
    (43747850971/50000000000:ℝ) < methodLimit ∧
      methodLimit < (874957019421/1000000000000:ℝ) := by
  obtain ⟨hR,hzero⟩ := methodLimit_spec
  have hl : 0 < boundaryPolynomial (43747850971/50000000000) := by
    norm_num [boundaryPolynomial]
  have hu : boundaryPolynomial (874957019421/1000000000000) < 0 := by
    norm_num [boundaryPolynomial]
  constructor
  · by_contra hh
    have hle : methodLimit ≤ (43747850971/50000000000:ℝ) := le_of_not_gt hh
    rcases lt_or_eq_of_le hle with hlt|heq
    · have hd := polynomial_strict_decrease hR.1 hR.2 (by norm_num) (by norm_num) hlt
      rw [hzero] at hd
      linarith
    · rw [heq] at hzero
      linarith
  · by_contra hh
    have hle : (874957019421/1000000000000:ℝ) ≤ methodLimit := le_of_not_gt hh
    rcases lt_or_eq_of_le hle with hlt|heq
    · have hd := polynomial_strict_decrease (by norm_num) (by norm_num) hR.1 hR.2 hlt
      rw [hzero] at hd
      linarith
    · rw [← heq] at hzero
      linarith

theorem criticalDelta_range (B : ℝ) (hl : 5/6 ≤ B) (hu : B ≤ 7/8) :
    0 ≤ criticalDelta B ∧ criticalDelta B ≤ 5/6 := by
  have hd : 0 < 18*(1-B) := by linarith
  constructor
  · exact div_nonneg (by linarith) hd.le
  · apply (div_le_iff₀ hd).2
    linarith

theorem inverse_boundary_identity (B : ℝ) (hB : B ≠ 1)
    (hd : 9+18*criticalDelta B ≠ 0) :
    (7+18*criticalDelta B)/(9+18*criticalDelta B)=B := by
  apply (div_eq_iff hd).2
  unfold criticalDelta
  field_simp [sub_ne_zero.mpr (Ne.symm hB)]
  ring

theorem count_polynomial_identity (B : ℝ) (hB : B ≠ 1)
    (hk : 2*B-1 ≠ 0) (hJ : countJ (2*B-1) (criticalDelta B) (1/2) ≠ 0) :
    1944*(2*B-1)*(1-B)^2*countJ (2*B-1) (criticalDelta B) (1/2)*
      (countR (2*B-1) (criticalDelta B) (1/2)-2/3)=boundaryPolynomial B := by
  unfold countR
  field_simp [hJ]
  simp only [countJ,countD,countA,primeWeight,criticalDelta,boundaryPolynomial]
  field_simp [hk,sub_ne_zero.mpr (Ne.symm hB)]
  ring

theorem delta_cubic_identity (B : ℝ) (hB : B ≠ 1) :
    27*(1-B)^3*(1188*(criticalDelta B)^3-2160*(criticalDelta B)^2+
      171*criticalDelta B+190)=2*boundaryPolynomial B := by
  unfold criticalDelta boundaryPolynomial
  field_simp [sub_ne_zero.mpr (Ne.symm hB)]
  ring

theorem dual_identity (B M ell δ : ℝ) (hd : 9+18*δ ≠ 0) :
    (4+18*δ)/(9+18*δ)*(B-lowFace M ell)+
    2/(9+18*δ)*(B-reflectedFace M ell)+
    3/(9+18*δ)*(B-highFace δ M ell)=B-(7+18*δ)/(9+18*δ) := by
  unfold lowFace reflectedFace highFace
  field_simp [hd]
  ring

/-- A necessary polynomial sign for the three explicitly stated scalar faces.
The hypotheses, including the high face, are not inferred from actual energy. -/
theorem three_face_polynomial_necessary (B κ M ell h : ℝ)
    (hBl : 5/6 ≤ B) (hBu : B ≤ 7/8) (hk : 2*B-1 ≤ κ) (hh : 0 < h)
    (h0 : lowFace M ell ≤ B) (hK : reflectedFace M ell ≤ B)
    (hH : highFace (criticalDelta B) M ell+
      h*(countR κ (criticalDelta B) (1/2)-2/3) ≤ B) :
    boundaryPolynomial B ≤ 0 := by
  let δ := criticalDelta B
  obtain ⟨hd0,hd1⟩ := criticalDelta_range B hBl hBu
  have hk0 : (2/3:ℝ) ≤ 2*B-1 := by linarith
  have hmon := (countR_monotone_lipschitz (2*B-1) κ δ (1/2) hk0 hk
    hd0 hd1 (by norm_num) (by norm_num)).1
  have hden : 0 < 9+18*δ := by dsimp [δ]; linarith
  have hB1 : B ≠ 1 := ne_of_lt (by linarith)
  have hback := inverse_boundary_identity B hB1 hden.ne'
  have hdual := dual_identity B M ell δ hden.ne'
  have hR : countR κ δ (1/2) ≤ 2/3 := by
    by_contra hn
    have hRp : 0 < countR κ δ (1/2)-2/3 := by linarith
    have hBp : 0 < B-highFace δ M ell := by
      have hp := mul_pos hh hRp
      dsimp [δ] at *
      linarith
    have hw0 : 0 ≤ (4+18*δ)/(9+18*δ) := by positivity
    have hwK : 0 ≤ 2/(9+18*δ) := by positivity
    have hwH : 0 < 3/(9+18*δ) := by positivity
    have hs0 := mul_nonneg hw0 (sub_nonneg.mpr h0)
    have hsK := mul_nonneg hwK (sub_nonneg.mpr hK)
    have hsH := mul_pos hwH hBp
    rw [hback] at hdual
    linarith
  have hself : countR (2*B-1) δ (1/2)-2/3 ≤ 0 := by linarith
  have hkp : 0 < 2*B-1 := by linarith
  have hJ := (generalized_countJ_bounds (2*B-1) δ (1/2) hk0
    hd0 hd1 (by norm_num) (by norm_num)).1
  have hid := count_polynomial_identity B hB1 hkp.ne' hJ.ne'
  rw [← hid]
  exact mul_nonpos_of_nonneg_of_nonpos (by positivity) hself

theorem three_face_method_lower_bound (B κ M ell h : ℝ)
    (hBl : 5/6 ≤ B) (hBu : B ≤ 7/8) (hk : 2*B-1 ≤ κ) (hh : 0 < h)
    (h0 : lowFace M ell ≤ B) (hK : reflectedFace M ell ≤ B)
    (hH : highFace (criticalDelta B) M ell+
      h*(countR κ (criticalDelta B) (1/2)-2/3) ≤ B) : methodLimit ≤ B := by
  have hp := three_face_polynomial_necessary B κ M ell h hBl hBu hk hh h0 hK hH
  obtain ⟨hR,hzero⟩ := methodLimit_spec
  by_contra hn
  have hlt : B < methodLimit := lt_of_not_ge hn
  have hh := polynomial_strict_decrease hBl hBu hR.1 hR.2 hlt
  rw [hzero] at hh
  linarith

/-- Physical length constraints imply the lower endpoint of the relevant interval. -/
theorem physical_low_face_lower_bound (B lx ly ell : ℝ)
    (hlx : ell < lx) (hly : ell < ly)
    (h0 : lowFace (lx+ly) ell ≤ B) : 5/6 < B := by
  unfold lowFace at h0
  linarith

/-- The explicit three-face obstruction covers every physical candidate.
No a priori interval restriction on B is required in this wrapper. -/
theorem physical_three_face_method_lower_bound (B κ lx ly ell h : ℝ)
    (hlx : ell < lx) (hly : ell < ly) (hk : 2*B-1 ≤ κ) (hh : 0 < h)
    (h0 : lowFace (lx+ly) ell ≤ B)
    (hK : reflectedFace (lx+ly) ell ≤ B)
    (hH : highFace (criticalDelta B) (lx+ly) ell+
      h*(countR κ (criticalDelta B) (1/2)-2/3) ≤ B) : methodLimit ≤ B := by
  by_cases hBu : B ≤ 7/8
  · have hBl := (physical_low_face_lower_bound B lx ly ell hlx hly h0).le
    exact three_face_method_lower_bound B κ (lx+ly) ell h hBl hBu hk hh h0 hK hH
  · exact methodLimit_spec.1.2.trans (lt_of_not_ge hBu).le

theorem methodLimit_critical_count :
    countR (2*methodLimit-1) (criticalDelta methodLimit) (1/2)=2/3 := by
  obtain ⟨hB,hzero⟩ := methodLimit_spec
  have hBlo := hB.1
  have hBhi := hB.2
  obtain ⟨hd0,hd1⟩ := criticalDelta_range methodLimit hB.1 hB.2
  have hk : (2/3:ℝ) ≤ 2*methodLimit-1 := by linarith
  have hkp : 0 < 2*methodLimit-1 := by linarith
  have hB1 : methodLimit ≠ 1 := ne_of_lt (by linarith)
  have hJ := (generalized_countJ_bounds (2*methodLimit-1) (criticalDelta methodLimit)
    (1/2) hk hd0 hd1 (by norm_num) (by norm_num)).1
  have hi := count_polynomial_identity methodLimit hB1 hkp.ne' hJ.ne'
  rw [hzero] at hi
  have hf : 0 < 1944*(2*methodLimit-1)*(1-methodLimit)^2*
      countJ (2*methodLimit-1) (criticalDelta methodLimit) (1/2) := by
    have hsq : 0 < (1-methodLimit)^2 := sq_pos_of_pos (by linarith)
    positivity
  have hz : countR (2*methodLimit-1) (criticalDelta methodLimit) (1/2)-2/3=0 :=
    (mul_eq_zero.mp hi).resolve_left hf.ne'
  linarith

theorem methodLimit_delta_cubic :
    1188*(criticalDelta methodLimit)^3-2160*(criticalDelta methodLimit)^2+
      171*criticalDelta methodLimit+190=0 := by
  obtain ⟨hB,hzero⟩ := methodLimit_spec
  have hBlo := hB.1
  have hBhi := hB.2
  have hB1 : methodLimit ≠ 1 := ne_of_lt (by linarith)
  have hi := delta_cubic_identity methodLimit hB1
  rw [hzero,mul_zero] at hi
  have hf : 27*(1-methodLimit)^3 ≠ 0 := by
    have hh : 0 < 1-methodLimit := by linarith
    positivity
  exact (mul_eq_zero.mp hi).resolve_left hf

theorem balanced_faces_attained :
    let ell := 11/3-4*methodLimit
    let M := 1-ell
    lowFace M ell=methodLimit ∧ reflectedFace M ell=methodLimit ∧
      highFace (criticalDelta methodLimit) M ell=methodLimit := by
  obtain ⟨hB,hzero⟩ := methodLimit_spec
  have hBlo := hB.1
  have hBhi := hB.2
  have hB1 : 1-methodLimit ≠ 0 := ne_of_gt (by linarith)
  dsimp only
  constructor
  · unfold lowFace; ring
  constructor
  · unfold reflectedFace; ring
  · unfold highFace criticalDelta
    field_simp [hB1]
    ring

theorem methodLimit_below_rational_target : methodLimit < boundary := by
  have hu := methodLimit_bracket.2
  unfold boundary
  linarith

#print axioms methodLimit_bracket
#print axioms three_face_method_lower_bound
#print axioms physical_three_face_method_lower_bound
#print axioms methodLimit_critical_count
#print axioms methodLimit_delta_cubic
#print axioms balanced_faces_attained
end
end QRHExtension.KappaMethodLimit
