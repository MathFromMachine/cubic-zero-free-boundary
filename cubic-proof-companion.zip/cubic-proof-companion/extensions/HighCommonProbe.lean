import OAI.NumberTheory.DirichletL.Hecke.CommonProbe

namespace OAI
noncomputable section
open Filter Asymptotics MeasureTheory
open scoped Topology Classical
namespace SevenEighths.Supremum.Extension
def continuationMargin (β ω σ : ℝ) : ℝ := min (β - 87499 / 100000 - ω) σ

theorem continuationMargin_pos {β ω σ : ℝ}
    (hω : ω < β - 87499 / 100000) (hσ : 0 < σ) :
    0 < continuationMargin β ω σ := by
  exact lt_min (sub_pos.mpr hω) hσ

theorem continuationMargin_le_gap (β ω σ : ℝ) :
    continuationMargin β ω σ ≤ β - 87499 / 100000 - ω :=
  min_le_left _ _

theorem continuationMargin_le_sigma (β ω σ : ℝ) :
    continuationMargin β ω σ ≤ σ :=
  min_le_right _ _

theorem continuation_boundary_gt {β ω σ : ℝ} (hω : 0 < ω) :
    87499 / 100000 < β - continuationMargin β ω σ := by
  have h := continuationMargin_le_gap β ω σ
  linarith

theorem max_signal_exponents (β ω σ c : ℝ) :
    max (87499 / 100000 + c + ω) (β + c - σ) =
      β + c - continuationMargin β ω σ := by
  unfold continuationMargin
  rcases le_total (β - 87499 / 100000 - ω) σ with h | h
  · rw [min_eq_left h, max_eq_left (by linarith)]
    linarith
  · rw [min_eq_right h, max_eq_right (by linarith)]

theorem max_normalized_signal_exponents (β ω σ : ℝ) :
    max (56249 / 300000 + ω) (β - 25781 / 37500 - σ) =
      β - 25781 / 37500 - continuationMargin β ω σ := by
  have h : (87499 / 100000 : ℝ) + -(25781 / 37500) = 56249 / 300000 := by norm_num
  simpa only [sub_eq_add_neg, h] using max_signal_exponents β ω σ (-(25781 / 37500))


end SevenEighths.Supremum.Extension
namespace SevenEighths.Continuation.Extension
theorem common_signal_bound_with_margin (J f : ℝ → ℂ) (β ω σ c : ℝ)
    (hJ : J =O[atTop] (fun x : ℝ => x ^ (87499 / 100000 + c + ω)))
    (herror : (fun x => J x - f x) =O[atTop]
      (fun x : ℝ => x ^ (β + c - σ))) :
    f =O[atTop] (fun x : ℝ =>
      x ^ (β + c - Supremum.Extension.continuationMargin β ω σ)) := by
  simpa only [Supremum.Extension.max_signal_exponents] using
    common_signal_bound J f (87499 / 100000 + c + ω) (β + c - σ) hJ herror

theorem nonzero_of_common_signal (β ω σ c : ℝ) (hω : 0 < ω)
    (L Lregular R H : ℂ → ℂ) (J f : ℝ → ℂ)
    (hL : AnalyticOnNhd ℂ Lregular
      {s : ℂ | β - Supremum.Extension.continuationMargin β ω σ < s.re})
    (hR : AnalyticOnNhd ℂ R
      {s : ℂ | β - Supremum.Extension.continuationMargin β ω σ < s.re})
    (hH : AnalyticOnNhd ℂ H {s : ℂ | 87499 / 100000 < s.re})
    (hcontract : ∀ s : ℂ, 87499 / 100000 < s.re → ‖H s - 1‖ ≤ (1 / 2 : ℝ))
    (hlocal : LocallyIntegrableOn f (Set.Ioi 0))
    (hzero : RapidDecayAtZero f)
    (hJ : J =O[atTop] (fun x : ℝ => x ^ (87499 / 100000 + c + ω)))
    (herror : (fun x => J x - f x) =O[atTop]
      (fun x : ℝ => x ^ (β + c - σ)))
    (heq : ∀ s : ℂ, max (β - Supremum.Extension.continuationMargin β ω σ) 1 < s.re →
      Lregular s * signalMellin f c s = R s * gaussianMultiplier H s)
    {ρ : ℂ} (hρ : β - Supremum.Extension.continuationMargin β ω σ < ρ.re)
    (hregular : Lregular ρ = R ρ * L ρ) (hRρ : R ρ ≠ 0) : L ρ ≠ 0 := by
  have hboundary := Supremum.Extension.continuation_boundary_gt (β := β) (σ := σ) hω
  have hH' : AnalyticOnNhd ℂ H
      {s : ℂ | β - Supremum.Extension.continuationMargin β ω σ < s.re} :=
    hH.mono (fun s hs => lt_trans hboundary hs)
  have htop : f =O[atTop] (fun x : ℝ =>
      x ^ ((β - Supremum.Extension.continuationMargin β ω σ) + c)) := by
    have hexp : (β - Supremum.Extension.continuationMargin β ω σ) + c =
        β + c - Supremum.Extension.continuationMargin β ω σ := by ring
    simpa only [hexp] using common_signal_bound_with_margin J f β ω σ c hJ herror
  exact nonzero_of_regularized_signal _ 1 c L Lregular R (gaussianMultiplier H) f
    hL hR (gaussianMultiplier_analytic hH') hlocal htop hzero heq hρ hregular
    hRρ (gaussianMultiplier_ne_zero (hcontract ρ (lt_trans hboundary hρ)))


end SevenEighths.Continuation.Extension
namespace SevenEighths.HeckeSignal.Extension
open HeckeFamily Continuation
theorem nonzero_of_probe_bounds (χ : Character) (H : ℂ → ℂ) (J : ℝ → ℂ)
    (β ω σ c : ℝ) (hβ : β ≤ 1) (hω0 : 0 < ω) (hω : ω < β-87499/100000) (hσ : 0 < σ)
    (hH : AnalyticOnNhd ℂ H {s : ℂ | 87499/100000 < s.re})
    (hb : ∀ s : ℂ, 87499/100000 < s.re → ‖H s - 1‖ ≤ 1/2)
    (hJ : J =O[atTop] (fun x : ℝ => x^(87499/100000+c+ω)))
    (herror : (fun x => J x - signal χ H c x) =O[atTop]
      (fun x : ℝ => x^(β+c-σ)))
    {ρ : ℂ} (hρ : β - Supremum.Extension.continuationMargin β ω σ < ρ.re)
    (hpole : ρ ≠ 1 ∨ χ.residue ≠ 1) : LFunction χ ρ ≠ 0 := by
  let a := β - Supremum.Extension.continuationMargin β ω σ
  have ha2 : a < 2 := by
    have hp := Supremum.Extension.continuationMargin_pos hω hσ
    dsimp [a]
    linarith
  have htop : signal χ H c =O[atTop] (fun x : ℝ => x^(a+c)) := by
    have h := Continuation.Extension.common_signal_bound_with_margin J (signal χ H c) β ω σ c hJ herror
    convert h using 1; dsimp [a]; ring_nf
  have hHold : AnalyticOnNhd ℂ H {s : ℂ | 7/8 < s.re} :=
    hH.mono (by intro s hs; change 7/8 < s.re at hs; change 87499/100000 < s.re; linarith)
  have hbold : ∀ s : ℂ, 7/8 < s.re → ‖H s - 1‖ ≤ 1/2 := by
    intro s hs; exact hb s (by linarith)
  have hHd := hHold.differentiableOn
  apply Continuation.Extension.nonzero_of_common_signal β ω σ c hω0 (LFunction χ) (regularL χ)
    (targetRegularizer χ) H J (signal χ H c)
    ((Complex.analyticOnNhd_univ_iff_differentiable.mpr (regularL_entire χ)).mono (Set.subset_univ _))
    ((Complex.analyticOnNhd_univ_iff_differentiable.mpr (targetRegularizer_entire χ)).mono (Set.subset_univ _))
    hH hb (signal_locallyIntegrable χ H hHd hbold c) (signal_rapidDecayAtZero χ H hHd hbold c)
    hJ herror _ hρ _ (targetRegularizer_ne_zero χ hpole)
  · intro s hs
    have hs1 : 1 < s.re := (le_max_right a 1).trans_lt hs
    have h0 : s ≠ 0 := by intro h; norm_num [h] at hs1
    have h1 : s ≠ 1 := by intro h; norm_num [h] at hs1
    rw [regularL_eq χ h0 (Or.inl h1), signalMellin_eq_amplitude χ H hHd hbold c a ha2 htop hs]
    unfold amplitude quotient gaussianMultiplier
    rw [HeckeReciprocal.reciprocal_eq_inv χ h0 h1]
    have hn := LFunction_ne_zero_of_one_lt_re χ hs1
    field_simp
  · apply regularL_eq χ _ hpole
    intro h
    have hbound := Supremum.Extension.continuation_boundary_gt (β := β) (σ := σ) hω0
    rw [h] at hρ
    norm_num at hρ
    linarith


end SevenEighths.HeckeSignal.Extension
namespace SevenEighths.HeckeDirichlet.Extension
open HeckeFamily
variable {q : ℕ} [NeZero q]
theorem dirichlet_candidate_of_hecke
    (hH : ∀ (η : Character) (s : ℂ), (87499/100000 : ℝ) < s.re →
      (s ≠ 1 ∨ η.residue ≠ 1) → LFunction η s ≠ 0)
    (χ : DirichletCharacter ℂ q) (s : ℂ) (hs : (87499/100000 : ℝ) < s.re)
    (hexc : ¬ (χ = 1 ∧ s = 1)) : χ.LFunction s ≠ 0 := by
  by_cases hge : 1 ≤ s.re
  · exact χ.LFunction_ne_zero_of_one_le_re (not_and_or.mp hexc) hge
  have hs1 : s ≠ 1 := by intro h; simp [h] at hge
  have hs0 : s ≠ 0 := by intro h; norm_num [h] at hs
  have h := hH (character χ) s hs (Or.inl hs1)
  rw [LFunction_eq_dirichlet_product χ hs0 hs1] at h
  exact (mul_ne_zero_iff.mp h).1

theorem zeta_candidate_of_hecke
    (hH : ∀ (η : Character) (s : ℂ), (87499/100000 : ℝ) < s.re →
      (s ≠ 1 ∨ η.residue ≠ 1) → LFunction η s ≠ 0)
    (s : ℂ) (hs : (87499/100000 : ℝ) < s.re) : riemannZeta s ≠ 0 := by
  by_cases h1 : s = 1
  · simpa [h1] using riemannZeta_one_ne_zero
  have h := dirichlet_candidate_of_hecke hH (1 : DirichletCharacter ℂ 1) s hs
    (by simp [h1])
  simpa only [DirichletCharacter.LFunction_modOne_eq] using h


end SevenEighths.HeckeDirichlet.Extension
namespace SevenEighths.HeckeCommonProbe.Extension
open HeckeFamily HeckeZeroSupremum
def PrimitiveContract (ω σ : ℝ) : Prop :=
  ∀ η : Character, FiniteFourier.IsPrimitiveOnIdeals η.residue →
    ∃ (χ : Character) (H : ℂ → ℂ) (J : ℝ → ℂ),
      (∀ I, idealCoeff χ I = if IsCoprime I χ.modulus then idealCoeff η I else 0) ∧
      AnalyticOnNhd ℂ H {s : ℂ | 87499/100000 < s.re} ∧
      (∀ s : ℂ, 87499/100000 < s.re → ‖H s - 1‖ ≤ 1/2) ∧
      J =O[atTop] (fun x : ℝ => x^(56249/300000+ω)) ∧
      (fun x => J x - HeckeSignal.signal χ H (-25781/37500) x) =O[atTop]
        (fun x : ℝ => x^(beta-25781/37500-σ))

def UniformCommonProbe : Prop :=
  87499/100000 < beta → ∃ ω σ : ℝ,
    0 < ω ∧ ω < beta-87499/100000 ∧ 0 < σ ∧ PrimitiveContract ω σ

theorem beta_le_candidate (h : UniformCommonProbe) : beta ≤ 87499/100000 := by
  by_contra hn
  obtain ⟨ω, σ, hω0, hω, hσ, hcontract⟩ := h (lt_of_not_ge hn)
  have hmargin := Supremum.Extension.continuationMargin_pos hω hσ
  have hboundary := Supremum.Extension.continuation_boundary_gt (β := beta) (σ := σ) hω0
  obtain ⟨η, ρ, hp, hhalf, _, hpole, hz, hnear⟩ :=
    HeckePrimitiveSupremum.exists_primitive_zero_near_beta hmargin (by linarith)
  obtain ⟨χ, H, J, hmask, hH, hb, hJ, herr⟩ := hcontract η hp
  have hχpole : ρ ≠ 1 ∨ χ.residue ≠ 1 := by
    rcases hpole with h1 | hη
    · exact Or.inl h1
    · exact Or.inr (fun hc => hη ((HeckeFiniteDeletion.principal_iff_of_mask χ η hmask).mp hc))
  have hzχ : LFunction χ ρ = 0 := by
    rw [HeckeFiniteDeletion.LFunction_eq_of_mask_nonpole χ η hmask (by linarith) hχpole,
      hz, zero_mul]
  apply (HeckeSignal.Extension.nonzero_of_probe_bounds χ H J beta ω σ (-25781/37500)
    beta_le_one hω0 hω hσ hH hb ?_ ?_ hnear hχpole) hzχ
  · convert hJ using 1; ring_nf
  · convert herr using 1; ring_nf

theorem hecke_ne_zero_of_common_probe (h : UniformCommonProbe)
    (χ : Character) (s : ℂ) (hs : (87499/100000 : ℝ) < s.re)
    (hpole : s ≠ 1 ∨ χ.residue ≠ 1) : LFunction χ s ≠ 0 := by
  exact LFunction_ne_zero_of_beta_lt χ ((beta_le_candidate h).trans_lt hs) hpole

theorem dirichlet_of_common_probe (h : UniformCommonProbe) (q : ℕ) (hq : q ≠ 0)
    (χ : DirichletCharacter ℂ q) (s : ℂ) (hs : (87499/100000 : ℝ) < s.re)
    (hexc : ¬ (χ = 1 ∧ s = 1)) :
    letI : NeZero q := ⟨hq⟩
    DirichletCharacter.LFunction χ s ≠ 0 := by
  let : NeZero q := ⟨hq⟩
  exact HeckeDirichlet.Extension.dirichlet_candidate_of_hecke
    (hecke_ne_zero_of_common_probe h) χ s hs hexc

theorem zeta_of_common_probe (h : UniformCommonProbe) (s : ℂ)
    (hs : (87499/100000 : ℝ) < s.re) : riemannZeta s ≠ 0 :=
  HeckeDirichlet.Extension.zeta_candidate_of_hecke (hecke_ne_zero_of_common_probe h) s hs


#print axioms zeta_of_common_probe
end SevenEighths.HeckeCommonProbe.Extension
end
end OAI
