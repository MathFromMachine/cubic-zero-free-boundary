import OAI.NumberTheory.DirichletL.Nonvanishing

namespace QRHExtension
open OAI.SevenEighths

/-- Reuse only the already verified original family bound. -/
theorem baseline_hecke_family_bound : HeckeZeroSupremum.beta ≤ (7 / 8 : ℝ) :=
  HeckeCommonProbe.beta_le_seven_eighths
    (ProbeFinalAssembly.common_probe_of_chosen_moments
      (ProbeFinalAssemblyCertifiedBands.chosen_moments_of_certified
        ProbeFinalAssemblyUnconditional.detector_certified_bands))

#print axioms baseline_hecke_family_bound
end QRHExtension
