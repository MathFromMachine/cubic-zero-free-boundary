import KappaRationalCertificate

/-! Finite-difference control of the generalized scalar count envelope.
No calculus and no new arithmetic row-count hypothesis is used here. -/
namespace QRHExtension.KappaOptimization
noncomputable section

theorem generalized_count_geometry (κ x : ℝ) (hk : 2/3 ≤ κ)
    (hx0 : 0 ≤ x) (hx1 : x ≤ 1/2) :
    3/2 ≤ countA κ x ∧ 2 ≤ countD κ x ∧ 3/4 ≤ primeWeight κ x := by
  have hkp : 0 < 3*κ := by linarith
  have hr : 2*x/(3*κ) ≤ 1/2 := (div_le_iff₀ hkp).2 (by linarith)
  have ha : 3/2 ≤ countA κ x := by unfold countA; linarith
  have hd : 2 ≤ countD κ x := by unfold countD; linarith
  have hp := mul_le_mul ha (show (1/2:ℝ) ≤ 1-x by linarith)
    (by norm_num : (0:ℝ) ≤ 1/2) (by linarith : 0 ≤ countA κ x)
  refine ⟨ha,hd,?_⟩
  unfold primeWeight
  nlinarith

theorem generalized_countJ_bounds (κ δ x : ℝ) (hk : 2/3 ≤ κ)
    (hd0 : 0 ≤ δ) (hd1 : δ ≤ 5/6) (hx0 : 0 ≤ x) (hx1 : x ≤ 1/2) :
    0 < countJ κ δ x ∧ 2*(5/6-δ) ≤ countJ κ δ x := by
  obtain ⟨hA,hD,hP⟩ := generalized_count_geometry κ x hk hx0 hx1
  have hs : 0 ≤ 5/6-δ := by linarith
  have h1 := mul_nonneg hs (show 0 ≤ countD κ x-3/4 by linarith)
  have h2 := mul_nonneg hd0 (show 0 ≤ primeWeight κ x-3/4 by linarith)
  have h3 := mul_nonneg hs (show 0 ≤ countD κ x-2 by linarith)
  have h4 := mul_nonneg hd0 (show 0 ≤ primeWeight κ x by linarith)
  unfold countJ
  constructor <;> nlinarith

theorem count_difference_identity (κ₁ κ₂ δ x : ℝ)
    (hk1 : κ₁ ≠ 0) (hk2 : κ₂ ≠ 0)
    (hJ1 : countJ κ₁ δ x ≠ 0) (hJ2 : countJ κ₂ δ x ≠ 0) :
    3*κ₁*κ₂*countJ κ₁ δ x*countJ κ₂ δ x*
        (countR κ₂ δ x-countR κ₁ δ x) =
      δ*(5/6-δ)^2*x*(1-x)^2*(κ₂-κ₁) := by
  unfold countR
  field_simp [hJ1,hJ2]
  unfold countJ countD primeWeight countA
  field_simp [hk1,hk2]
  ring

theorem countR_monotone_lipschitz (κ₁ κ₂ δ x : ℝ)
    (hk1 : 2/3 ≤ κ₁) (hk12 : κ₁ ≤ κ₂)
    (hd0 : 0 ≤ δ) (hd1 : δ ≤ 5/6) (hx0 : 0 ≤ x) (hx1 : x ≤ 1/2) :
    0 ≤ countR κ₂ δ x-countR κ₁ δ x ∧
      countR κ₂ δ x-countR κ₁ δ x ≤ (κ₂-κ₁)/8 := by
  have hk2 : 2/3 ≤ κ₂ := hk1.trans hk12
  have hkp1 : 0 < κ₁ := by linarith
  have hkp2 : 0 < κ₂ := by linarith
  obtain ⟨hJ1,hJs1⟩ := generalized_countJ_bounds κ₁ δ x hk1 hd0 hd1 hx0 hx1
  obtain ⟨hJ2,hJs2⟩ := generalized_countJ_bounds κ₂ δ x hk2 hd0 hd1 hx0 hx1
  let s := 5/6-δ
  let N := δ*s^2*x*(1-x)^2
  let Den := 3*κ₁*κ₂*countJ κ₁ δ x*countJ κ₂ δ x
  have hs : 0 ≤ s := by dsimp [s]; linarith
  have hN : 0 ≤ N := by dsimp [N]; positivity
  have hDen : 0 < Den := by dsimp [Den]; positivity
  have hdiff : 0 ≤ κ₂-κ₁ := by linarith
  have hi : Den*(countR κ₂ δ x-countR κ₁ δ x)=N*(κ₂-κ₁) :=
    count_difference_identity κ₁ κ₂ δ x hkp1.ne' hkp2.ne' hJ1.ne' hJ2.ne'
  have hkk : (4/9:ℝ) ≤ κ₁*κ₂ := by
    have hh := mul_le_mul hk1 hk2 (by norm_num : (0:ℝ) ≤ 2/3) hkp1.le
    nlinarith
  have hJJ : 4*s^2 ≤ countJ κ₁ δ x*countJ κ₂ δ x := by
    have hh := mul_le_mul hJs1 hJs2 (by dsimp [s] at hs; linarith) hJ1.le
    dsimp only [s]
    nlinarith
  have hDenBound : (16/3)*s^2 ≤ Den := by
    have hh := mul_le_mul hkk hJJ (by positivity : 0 ≤ 4*s^2)
      (mul_nonneg hkp1.le hkp2.le)
    dsimp only [Den]
    nlinarith
  have hdx : δ*x ≤ (5/12:ℝ) := by
    have hh := mul_le_mul hd1 hx1 hx0 (by norm_num : (0:ℝ) ≤ 5/6)
    nlinarith
  have hxSquare : (1-x)^2 ≤ 1 := by
    nlinarith [mul_nonneg hx0 (show 0 ≤ 2-x by linarith)]
  have hshape : δ*x*(1-x)^2 ≤ (5/12:ℝ) := by
    have hh := mul_le_mul hdx hxSquare (sq_nonneg (1-x))
      (by norm_num : (0:ℝ) ≤ 5/12)
    nlinarith
  have hNBound : 8*N ≤ Den := by
    calc
      8*N = (8*(δ*x*(1-x)^2))*s^2 := by dsimp [N]; ring
      _ ≤ (8*(5/12:ℝ))*s^2 :=
        mul_le_mul_of_nonneg_right (by linarith) (sq_nonneg s)
      _ ≤ Den := by nlinarith [sq_nonneg s]
  constructor
  · apply nonneg_of_mul_nonneg_right (a := Den) (by rw [hi]; positivity) hDen
  · have hm := mul_le_mul_of_nonneg_right hNBound hdiff
    have hscaled : Den*(countR κ₂ δ x-countR κ₁ δ x) ≤ Den*((κ₂-κ₁)/8) := by
      rw [hi]
      nlinarith
    exact le_of_mul_le_mul_left hscaled hDen

theorem shifted_all_bins_margin (Δ δ x : ℝ) (hΔ : 0 ≤ Δ)
    (hd0 : 0 ≤ δ) (hd1 : δ ≤ 5/6) (hx0 : 0 ≤ x) (hx1 : x ≤ 1/2) :
    exponent (kappa+2*Δ) δ x-Δ ≤ -(1/100000000:ℝ)-3*Δ/4 := by
  have hk : (2/3:ℝ) ≤ kappa := by norm_num [kappa]
  have hc := countR_monotone_lipschitz kappa (kappa+2*Δ) δ x hk (by linarith)
    hd0 hd1 hx0 hx1
  have he := all_bins_margin δ x hd0 hd1 hx0 hx1
  have hh : 0 ≤ h := by norm_num [h]
  have hhu : h ≤ 1 := by norm_num [h]
  have hm := mul_le_mul_of_nonneg_left hc.2 hh
  have hbudget := mul_le_mul_of_nonneg_right hhu hΔ
  unfold exponent at *
  nlinarith

#print axioms count_difference_identity
#print axioms countR_monotone_lipschitz
#print axioms shifted_all_bins_margin
end
end QRHExtension.KappaOptimization
