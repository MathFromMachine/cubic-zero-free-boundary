import KappaCertifiedExistence

/-! Audit entry for the actual centered-moment induction. The theorem below is
the terminal certificate about the original arithmetic energy objects, with
geometric floor 13/18 and the separate analytic requirement 2 beta - 1 <= kappa.
No improved zero-free theorem is asserted here. -/

#check OAI.SevenEighths.CenteredMomentEnergyCertifiedExistenceKappa.certified_bands
#check OAI.SevenEighths.CenteredMomentEnergyCertifiedExistenceKappa.terminal_certificate
#print axioms OAI.SevenEighths.CenteredMomentEnergyCertifiedExistenceKappa.certified_bands
#print axioms OAI.SevenEighths.CenteredMomentEnergyCertifiedExistenceKappa.terminal_certificate

namespace QRHExtension.KappaTerminal
noncomputable section

def target : ℝ := 34998281/40000000
def kappaBase : ℝ := 37495707/50000000
def kappaAt (beta : ℝ) : ℝ := kappaBase+2*(beta-target)

theorem exact_analytic_margin (beta : ℝ) :
    kappaAt beta = 2*beta-1+9/100000000 := by
  unfold kappaAt kappaBase target
  ring

theorem admissible (beta : ℝ) (hbeta : target ≤ beta) :
    (13/18:ℝ) ≤ kappaAt beta ∧ 2*beta-1 ≤ kappaAt beta := by
  rw [exact_analytic_margin]
  unfold target at hbeta
  constructor <;> linarith

theorem bounded (beta : ℝ) (hbeta : beta ≤ 7/8) : kappaAt beta < 5/6 := by
  rw [exact_analytic_margin]
  linarith

#print axioms admissible
end
end QRHExtension.KappaTerminal
