import OAI.NumberTheory.DirichletL.Detector.FinalAssemblySource

/-!
# Arbitrary-total ray normalizer and a conditional normalized low wrapper

The first theorem proves an inverse bound for the actual normalizer using
the existing ray-prime theorem, with arbitrary total slot length.
The final theorem keeps the unnormalized physical-probe bound as an explicit
hypothesis. It does not prove that missing low estimate or a zero-free region.
-/

namespace QRHExtension.LowProof

noncomputable section
open scoped Classical BigOperators Topology ContDiff
open Filter Asymptotics
open OAI.SevenEighths
open HeckeFamily ProbePhysical ProbeRaySlots PrincipalSignalComparison
open PrincipalMellinResidues ProbePrincipalResidueActual
local notation "O" => HeckeFamily.O

/-- The actual residue normalizer, with the total slot length explicit. -/
def rayNormalizer {K : ℕ}
    (M : Ideal O) [NeZero M] [Finite (O ⧸ M)]
    (H : Subgroup (O ⧸ M)ˣ) (S : Finset (Ideal O))
    [NeZero (∏ P ∈ S, P)] (ell : Fin K → ℝ) (ellTotal a b : ℝ)
    (W : Fin K → ℝ → ℝ) (W0 W1 : SchwartzMap ℝ ℂ) (Z : ℝ) : ℂ :=
  let Yp := fun j => Z ^ (ell j)
  let T := fun j => pool (RayQuotient.identityClass M H) S a b (Yp j)
  sourceResidueConstant W0 W1 (∏ P ∈ S, P) *
    (Probe.principalScalar Finset.univ Z ellTotal (slotMass T (residueWeights W Yp)) : ℂ)

/-- The unchanged physical probe evaluated at arbitrary power scales. -/
def unnormalizedProbe {K : ℕ}
    (M : Ideal O) [NeZero M] [Finite (O ⧸ M)]
    (H : Subgroup (O ⧸ M)ˣ) (S : Finset (Ideal O))
    (hmax : ∀ P ∈ S, P.IsMaximal) (ell : Fin K → ℝ) (a b lx ly : ℝ)
    (W : Fin K → ℝ → ℝ) (W0 W1 : SchwartzMap ℝ ℂ)
    (η : Character) (Z : ℝ) : ℂ :=
  let Yp := fun j => Z ^ (ell j)
  let T := fun j => pool (RayQuotient.identityClass M H) S a b (Yp j)
  compensatedPhysicalProbe η (calibrationForSet S hmax) W0 W1
    (fun j => canonicalSlotSupport (T j)) (fun j y => (W j y : ℂ)) Yp
    (Z ^ lx) (Z ^ ly) Z

/-- The same physical probe divided by the same actual residue normalizer. -/
def normalizedProbe {K : ℕ}
    (M : Ideal O) [NeZero M] [Finite (O ⧸ M)]
    (H : Subgroup (O ⧸ M)ˣ) (S : Finset (Ideal O))
    (hmax : ∀ P ∈ S, P.IsMaximal) [NeZero (∏ P ∈ S, P)]
    (ell : Fin K → ℝ) (ellTotal a b lx ly : ℝ)
    (W : Fin K → ℝ → ℝ) (W0 W1 : SchwartzMap ℝ ℂ)
    (η : Character) (Z : ℝ) : ℂ :=
  unnormalizedProbe M H S hmax ell a b lx ly W W0 W1 η Z /
    rayNormalizer M H S ell ellTotal a b W W0 W1 Z

/-- Generalization of the existing `actual_ray_normalizer_inverse` from
total slot length 1/6 to any total equal to the sum of the positive lengths. -/
theorem actual_ray_normalizer_inverse_total {K : ℕ}
    (M : Ideal O) [NeZero M] [Finite (O ⧸ M)]
    (H : Subgroup (O ⧸ M)ˣ) (hH : RayOrthogonality.globalUnits M ≤ H)
    (S : Finset (Ideal O)) (hS : SourceExclusions S)
    (a b : ℝ) (ha : 0 < a) (hab : a ≤ b)
    (ell : Fin K → ℝ) (ellTotal : ℝ)
    (hell : ∀ j, 0 < ell j) (hsum : ∑ j, ell j = ellTotal)
    (W : Fin K → ℝ → ℝ) (hW : ∀ j, ContDiff ℝ ∞ (W j))
    (hcompact : ∀ j, HasCompactSupport (W j))
    (hsupp : ∀ j, Function.support (W j) ⊆ Set.Ioo a b)
    (hp : ∀ j y, 0 ≤ W j y) (hne : ∀ j, W j ≠ 0)
    (W0 W1 : SchwartzMap ℝ ℂ) (a0 b0 a1 b1 : ℝ)
    (ha0 : 0 < a0) (ha1 : 0 < a1)
    (hW0 : Function.support W0 ⊆ Set.Icc a0 b0)
    (hW1 : Function.support W1 ⊆ Set.Icc a1 b1)
    (hr0 : ∀ y, (W0 y).im = 0) (hr1 : ∀ y, (W1 y).im = 0)
    (hp0 : ∀ y, 0 ≤ (W0 y).re) (hp1 : ∀ y, 0 ≤ (W1 y).re)
    (hn0 : W0 ≠ 0) (hn1 : W1 ≠ 0) (nu : ℝ) (hnu : 0 < nu) :
    letI : NeZero (∏ P ∈ S, P) := ⟨fixedPrimeProduct_ne_zero S hS.prime⟩
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ Z : ℝ in atTop,
      rayNormalizer M H S ell ellTotal a b W W0 W1 Z ≠ 0 ∧
      ‖(rayNormalizer M H S ell ellTotal a b W W0 W1 Z)⁻¹‖ ≤ C * Z ^ nu := by
  let : NeZero (∏ P ∈ S, P) := ⟨fixedPrimeProduct_ne_zero S hS.prime⟩
  let cs := sourceResidueConstant W0 W1 (∏ P ∈ S, P)
  refine ⟨‖cs⁻¹‖ + 1, by positivity, ?_⟩
  have hpos (j : Fin K) : tsupport (W j) ⊆ Set.Ioi 0 := by
    apply Set.Subset.trans
      (closure_minimal (Set.Subset.trans (hsupp j) Set.Ioo_subset_Icc_self) isClosed_Icc)
    intro y hy
    exact lt_of_lt_of_le ha hy.1
  filter_upwards [power_ray_mass_and_normalizer M H hH S W a b ha hab hsupp hW hcompact
    hpos hp hne ell hell nu hnu, eventually_gt_atTop (0 : ℝ)] with Z hmass hZ
  dsimp only [rayNormalizer]
  refine ⟨ProbePrincipalNormalizer.signed_source_normalizer_ne_zero (∏ P ∈ S, P)
    W0 W1 a0 b0 a1 b1 ha0 ha1 hW0 hW1 hr0 hr1 hp0 hp1 hn0 hn1 Finset.univ
    (fun j => pool (RayQuotient.identityClass M H) S a b (Z ^ (ell j)))
    (residueWeights W (fun j => Z ^ (ell j))) Z ellTotal hZ (fun j _ => hmass.1 j), ?_⟩
  have hb : ‖(sourceResidueConstant W0 W1 (∏ P ∈ S, P) *
      (Probe.principalScalar Finset.univ Z ellTotal
        (slotMass (fun j => pool (RayQuotient.identityClass M H) S a b (Z ^ (ell j)))
          (residueWeights W (fun j => Z ^ (ell j)))) : ℂ))⁻¹‖ ≤ ‖cs⁻¹‖ * Z ^ nu := by
    rw [mul_inv_rev, norm_mul, ← Complex.ofReal_inv, Complex.norm_real]
    simpa only [hsum, Real.norm_eq_abs, mul_comm] using
      mul_le_mul_of_nonneg_left hmass.2 (norm_nonneg cs⁻¹)
  exact hb.trans (mul_le_mul_of_nonneg_right (by linarith) (Real.rpow_nonneg hZ.le _))

/-- Conditional normalization step. The missing estimate concerns the actual
unnormalized physical probe at exactly the same slot data and power scales.
The normalizer consumes half the positive loss allowance. -/
theorem normalizedProbe_low_of_unnormalized {K : ℕ}
    (M : Ideal O) [NeZero M] [Finite (O ⧸ M)]
    (H : Subgroup (O ⧸ M)ˣ) (hH : RayOrthogonality.globalUnits M ≤ H)
    (S : Finset (Ideal O)) (hS : SourceExclusions S) (hmax : ∀ P ∈ S, P.IsMaximal)
    (a b lx ly r loss : ℝ) (ha : 0 < a) (hab : a ≤ b) (hloss : 0 < loss)
    (ell : Fin K → ℝ) (ellTotal : ℝ)
    (hell : ∀ j, 0 < ell j) (hsum : ∑ j, ell j = ellTotal)
    (W : Fin K → ℝ → ℝ) (hW : ∀ j, ContDiff ℝ ∞ (W j))
    (hcompact : ∀ j, HasCompactSupport (W j))
    (hsupp : ∀ j, Function.support (W j) ⊆ Set.Ioo a b)
    (hp : ∀ j y, 0 ≤ W j y) (hne : ∀ j, W j ≠ 0)
    (W0 W1 : SchwartzMap ℝ ℂ) (a0 b0 a1 b1 : ℝ)
    (ha0 : 0 < a0) (ha1 : 0 < a1)
    (hW0 : Function.support W0 ⊆ Set.Icc a0 b0)
    (hW1 : Function.support W1 ⊆ Set.Icc a1 b1)
    (hr0 : ∀ y, (W0 y).im = 0) (hr1 : ∀ y, (W1 y).im = 0)
    (hp0 : ∀ y, 0 ≤ (W0 y).re) (hp1 : ∀ y, 0 ≤ (W1 y).re)
    (hn0 : W0 ≠ 0) (hn1 : W1 ≠ 0)
    (hraw : ∀ η : Character, ∃ Cp : ℝ, 0 < Cp ∧ ∀ᶠ Z : ℝ in atTop,
      ‖unnormalizedProbe M H S hmax ell a b lx ly W W0 W1 η Z‖ ≤
        Cp * Z ^ (r + loss / 2)) :
    letI : NeZero (∏ P ∈ S, P) := ⟨fixedPrimeProduct_ne_zero S hS.prime⟩
    ∀ η : Character,
      normalizedProbe M H S hmax ell ellTotal a b lx ly W W0 W1 η =O[atTop]
        (fun Z : ℝ => Z ^ (r + loss)) := by
  let : NeZero (∏ P ∈ S, P) := ⟨fixedPrimeProduct_ne_zero S hS.prime⟩
  obtain ⟨Cn, hCn, hnorm⟩ := actual_ray_normalizer_inverse_total M H hH S hS a b ha hab
    ell ellTotal hell hsum W hW hcompact hsupp hp hne W0 W1 a0 b0 a1 b1 ha0 ha1
    hW0 hW1 hr0 hr1 hp0 hp1 hn0 hn1 (loss / 2) (by positivity)
  intro η
  obtain ⟨Cp, hCp, hprobe⟩ := hraw η
  apply ProbeFinalAssembly.isBigO_rpow_of_eventual_norm_bound
  refine ⟨Cp * Cn, mul_pos hCp hCn, ?_⟩
  filter_upwards [hprobe, hnorm, eventually_gt_atTop (0 : ℝ)] with Z hpZ hnZ hZ
  rw [normalizedProbe, div_eq_mul_inv, norm_mul]
  calc
    _ ≤ (Cp * Z ^ (r + loss / 2)) * (Cn * Z ^ (loss / 2)) :=
      mul_le_mul hpZ hnZ.2 (norm_nonneg _) (by positivity)
    _ = (Cp * Cn) * Z ^ (r + loss) := by
      rw [mul_mul_mul_comm, ← Real.rpow_add hZ]
      congr 2
      ring

#print axioms actual_ray_normalizer_inverse_total
#print axioms normalizedProbe_low_of_unnormalized

end
end QRHExtension.LowProof
