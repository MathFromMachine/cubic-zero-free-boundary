import KappaDetectorRawBranches
import KappaDetectorBranchBudget

namespace OAI

noncomputable section
open scoped Classical BigOperators ContDiff
open Set Filter
namespace SevenEighths.HeckeDetectorCountFromMomentsKappa
open HeckeFamily HeckeInverseAmplification HeckeDetectorRawFiber HeckeDetectorBranchBudgetKappa
open HeckeDetectorRowCount

theorem count_from_raw_moments
    (M : Ideal O) [NeZero M] (H : Subgroup (O ⧸ M)ˣ)
    (hH : RayOrthogonality.globalUnits M≤H) (S : Finset (Ideal O))
    (φ : ℝ→ℝ) (hφ : ContDiff ℝ ∞ φ) (hφc : HasCompactSupport φ)
    (hφp : tsupport φ⊆Ioi 0) (hφ0 : ∀ y,0≤φ y) (hφne : φ≠0)
    (a₀ b₀ B₀ : ℝ) (ha₀ : 0<a₀) (hab₀ : a₀≤b₀) (hB₀ : 0<B₀)
    (hφs : Function.support φ⊆Ioo a₀ b₀) (hφB : ∀ y,φ y≤B₀)
    (εm : ℝ) (hεm : 0<εm) :
    ∃ c κraw K₀ : ℝ,0<c ∧ c≤1 ∧ 0<κraw ∧ 0≤K₀ ∧ ∀ᶠ U : ℝ in atTop,
      ∀ (a ε tstar T allowance κ ν C height : ℝ) (i : ℕ),
      1<U → 51/100<a → 2*a-1≤5/6 → 0≤ε → ε≤1/1000 →
      1≤tstar → tstar≤3/2 → 2/3≤κ → κ≤3/4 → 0<ν → 0≤C → 0≤height →
      2*Real.pi*allowance+(3*i : ℕ)*T≤height →
      ∀ {Label Slot : Type*} (F : Fiber M H Label Slot U a ε tstar T allowance i),
      Moments F ((κ-3/4)/2) c κraw C height εm →
      (F.rows.card : ℝ)≤fiberConstant C height K₀*
        U^(max (QRHExtension.KappaCounts.shortExponent κ (2*a-1) (F.q/(2*a-1)) tstar) (longExponent (2*a-1) tstar)+
          159*ε+εm+F.mesh+7*ν) := by
  obtain ⟨c,κraw,K₀,hc,hc1,hκraw,hK,hamp⟩ := HeckeDetectorNoSlotInverseCount.no_slot_inverse_count
    M H hH S φ hφ hφc hφp hφ0 hφne a₀ b₀ B₀ ha₀ hab₀ hB₀ hφs hφB 2 εm (by norm_num) hεm
  refine ⟨c,κraw,K₀,hc,hc1,hκraw,hK,?_⟩
  filter_upwards [hamp] with U hamp
  intro a ε tstar T allowance κ ν C height i hU ha hδcap hε hεsmall ht ht' hκ hκ' hν hC hh hf
    Label Slot F moments
  let δ := 2*a-1
  let x := F.q/δ
  have hδ : 0<δ := by dsimp [δ]; linarith
  have ha' : 1/2≤a := by linarith
  have hδ1 : δ≤1 := by dsimp [δ]; linarith
  obtain ⟨hq0,hqδ⟩ := F.mean_bounds ha'
  have hx : 0≤x := div_nonneg hq0 hδ.le
  have hx' : x≤1/2 := (div_le_iff₀ hδ).mpr (by dsimp [δ]; linarith)
  have hqx : δ*x=F.q := by dsimp [x]; field_simp
  have hgeom := F.lengths hU
  have hr0 : 0≤F.r := by linarith [hgeom.2.2.2.1]
  have hr2 : F.r≤2 := by linarith [hgeom.2.1]
  have hUp : 0<U := zero_lt_one.trans hU
  obtain ⟨hconst,hconstP,hconstI,hconstI0⟩ := fiberConstant_bounds C height K₀ hC hh hK
  have promote (C' p q : ℝ) (hC' : C'≤fiberConstant C height K₀)
      (hb : (F.rows.card : ℝ)≤C'*U^p) (hpq : p≤q) :
      (F.rows.card : ℝ)≤fiberConstant C height K₀*U^q := by
    exact hb.trans ((mul_le_mul_of_nonneg_right hC' (Real.rpow_nonneg hUp.le _)).trans
      (mul_le_mul_of_nonneg_left (Real.rpow_le_rpow_of_exponent_le hU.le hpq) hconst))
  have hi0 := hamp F.rows F.family a ε tstar T allowance i hU ha'
    (fun u => (F.witness u).toWitness) F.label F.left F.right F.fixed_label F.fixed_left F.fixed_right
    hr0 hr2 F.rowData F.reverse C height hC hh hf F.row_norm F.row_coeff moments.inverse_raw
  have hI0 : (F.rows.card : ℝ)≤fiberConstant C height K₀*
      U^(max 1 ((1+5*F.r)/6)-δ*F.r+commonLoss ε εm F.mesh ν) := by
    apply promote _ _ _ hconstI0 hi0
    exact no_slot_inverse_loss F.r δ ε εm F.mesh ν hε F.mesh_nonneg hν.le
  have hp0 := F.plain_unmarked_count moments hU (by linarith) hC hh hf
  have hP0 : (F.rows.card : ℝ)≤fiberConstant C height K₀*
      U^(1-2*δ*F.m+commonLoss ε εm F.mesh ν) := by
    apply promote _ _ _ hconstP hp0
    exact no_slot_plain_loss F.m δ ε εm F.mesh ν hε hgeom.2.2.1 F.mesh_nonneg hν.le
  have hI : 23/37≤F.r → F.r<1 → ν<(1-F.r)/2 →
      (F.rows.card : ℝ)≤fiberConstant C height K₀*
        U^(inverseExponent δ x F.r+commonLoss ε εm F.mesh ν) := by
    intro hr hr1 hv
    obtain ⟨hz,hz',hcap1,hcap2⟩ := inverse_requested_capacity F.r ν hr hr1 hν hv
    have hb := F.inverse_marked_count moments hU ha' hC hh hf ((1-F.r)/2-ν) hz hz' hcap1 hcap2
    apply promote _ _ _ hconstI hb
    have hl := inverse_marked_loss F.r δ x ε εm F.mesh ν hδ.le hδ1 hx hx' hε F.mesh_nonneg hν.le
    rwa [hqx] at hl
  have hP : F.r≤QRHExtension.KappaCounts.crossing κ x tstar → F.m<1/2 → ν<(1-2*F.m)/(6*κ) →
      (F.rows.card : ℝ)≤fiberConstant C height K₀*
        U^(1-2*δ*F.m-2*(δ*x)*(1-2*F.m)/(6*κ)+commonLoss ε εm F.mesh ν) := by
    intro hr hm hv
    obtain ⟨hz,hz',hcap⟩ := plain_requested_capacity κ x tstar F.r F.m ε ν hκ hκ' hx hx' ht ht'
      hr hgeom.1 (by linarith) hν.le hv
    have hb := HeckeDetectorRawFiberKappa.plain_marked_count F moments hU ha' (by linarith) hC hh hf
      ((1-2*F.m)/(6*κ)-ν) hz hz' hcap
    apply promote _ _ _ hconstP hb
    have hl := plain_marked_loss F.m δ x κ ε εm F.mesh ν hδ.le hδ1 hx hx' hε F.mesh_nonneg hν.le
    simpa only [hqx] using hl
  have hc' := QRHExtension.KappaCounts.count_bound_of_source_branches (F.rows.card : ℝ) (fiberConstant C height K₀) U κ δ x
    tstar F.r F.m (commonLoss ε εm F.mesh ν) ν ε hconst hU.le hκ hκ' hδ.le hδcap hx hx'
    ht ht' hν.le hε hgeom.1 hgeom.2.1 hI0 hP0 hI hP
  apply hc'.trans
  apply mul_le_mul_of_nonneg_left _ hconst
  apply Real.rpow_le_rpow_of_exponent_le hU.le
  dsimp only [δ,x]
  unfold commonLoss
  linarith

end SevenEighths.HeckeDetectorCountFromMomentsKappa

end

end OAI
