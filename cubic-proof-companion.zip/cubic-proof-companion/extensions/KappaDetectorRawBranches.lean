import OAI.NumberTheory.DirichletL.Hecke.DetectorRawBranches

namespace OAI
noncomputable section
open scoped Classical BigOperators
namespace SevenEighths.HeckeDetectorRawFiberKappa
open HeckeFamily HeckeDetectorRawFiber HeckeDetectorPlainFiberCount
variable {M : Ideal O} {H : Subgroup (O ⧸ M)ˣ} {Label Slot : Type*}
  {U a ε tstar T allowance : ℝ} {i : ℕ}

theorem plain_marked_count (F : Fiber M H Label Slot U a ε tstar T allowance i)
    {κ c κraw C height εm : ℝ} (moments : Moments F ((κ-3/4)/2) c κraw C height εm)
    (hU : 1<U) (ha : 1/2≤a) (hκ : 0≤κ) (hC : 0≤C) (hh : 0≤height)
    (hf : 2*Real.pi*allowance+(3*i : ℕ)*T≤height)
    (z : ℝ) (hz : 0≤z) (hz' : z≤7/37) (hcap : 2*F.m+6*κ*z≤1) :
    (F.rows.card : ℝ)≤(192*(1+height)*C)*U^(1-2*(2*a-1)*F.m-2*F.q*z+4*ε+(2*a-1)*F.mesh+εm) := by
  have hkappa : (3/4:ℝ)+2*((κ-3/4)/2)=κ := by ring
  exact plain_fiber_count M H F.rows F.nonempty F.family U a ε tstar T allowance i hU ha
    (fun u => (F.witness u).toWitness) F.label F.left F.right F.fixed_label F.fixed_left F.fixed_right
    F.slots (fun u => u.val) F.profile F.upper F.widths F.bin F.external F.mesh F.binWidth z κ εm C height
    F.mesh_nonneg F.binWidth_pos F.widths_pos F.widths_mesh (by linarith [F.supply])
    hz (hz'.trans F.supply) F.fixed_bin hκ hC hh hf hcap
    (by simpa only [Fiber.m, Fiber.physicalProduct, hkappa] using moments.plain_marked)

end SevenEighths.HeckeDetectorRawFiberKappa
end
end OAI
