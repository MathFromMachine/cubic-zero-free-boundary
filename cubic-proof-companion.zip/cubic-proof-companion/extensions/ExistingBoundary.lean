import HighUnconditional
import KappaTerminalAudit

/-! Explicit bootstrap from the previously verified, unchanged 0.87499 proof.
This theorem does not use any candidate V3 conclusion or Liu analytic theorem. -/
namespace QRHExtension.PreviousBoundary
noncomputable section
open OAI.SevenEighths

theorem beta_le_verified : HeckeZeroSupremum.beta ≤ (87499/100000:ℝ) :=
  HeckeCommonProbe.Extension.beta_le_candidate
    (ProbeFinalAssembly.Extension.common_probe_of_chosen_moments
      (ProbeFinalAssemblyCertifiedBands.Extension.chosen_moments_of_certified
        ProbeFinalAssemblyUnconditional.Extension.detector_certified_bands))

theorem candidate_kappa_lt_three_quarters :
    KappaTerminal.kappaAt HeckeZeroSupremum.beta < (3/4:ℝ) := by
  rw [KappaTerminal.exact_analytic_margin]
  linarith [beta_le_verified]

#print axioms beta_le_verified
#print axioms candidate_kappa_lt_three_quarters
end
end QRHExtension.PreviousBoundary
