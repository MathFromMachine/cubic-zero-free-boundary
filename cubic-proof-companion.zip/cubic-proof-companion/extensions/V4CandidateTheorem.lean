import V4Theorem

/-! Exact signatures for the independent Mathlib-only statement audit. -/
namespace QRHV4

theorem endpoint_exists : ∃ B : ℝ, (43747850971/50000000000:ℝ) < B ∧
    B < (874957019421/1000000000000:ℝ) ∧
    7884*B^3-18819*B^2+14643*B-3686=0 := by
  exact ⟨QRHExtension.KappaMethodLimit.methodLimit,
    QRHExtension.KappaMethodLimit.methodLimit_bracket.1,
    QRHExtension.KappaMethodLimit.methodLimit_bracket.2,
    QRHExtension.KappaMethodLimit.methodLimit_spec.2⟩

theorem zeta_nonvanishing {B : ℝ} {s : ℂ}
    (hBlo : (5/6:ℝ) ≤ B) (hBhi : B ≤ (7/8:ℝ))
    (hpoly : 7884*B^3-18819*B^2+14643*B-3686=0)
    (hs : B < s.re) (hpole : s ≠ 1) : _root_.riemannZeta s ≠ 0 := by
  exact QRHExtension.V4.zeta_nonvanishing_at_cubic_root hBlo hBhi hpoly hs hpole

theorem dirichlet_nonvanishing {B : ℝ}
    (hBlo : (5/6:ℝ) ≤ B) (hBhi : B ≤ (7/8:ℝ))
    (hpoly : 7884*B^3-18819*B^2+14643*B-3686=0)
    {q : ℕ} (hq : q ≠ 0) (χ : DirichletCharacter ℂ q) (s : ℂ)
    (hs : B < s.re) (hpole : ¬ (χ=1 ∧ s=1)) :
    letI : NeZero q := ⟨hq⟩
    DirichletCharacter.LFunction χ s ≠ 0 := by
  exact QRHExtension.V4.dirichlet_nonvanishing_at_cubic_root hBlo hBhi hpoly q hq χ s hs hpole

theorem zeta_rational {s : ℂ}
    (hs : (874957019421/1000000000000:ℝ) < s.re) (hpole : s ≠ 1) :
    _root_.riemannZeta s ≠ 0 := by
  exact QRHExtension.V4.ordinary_zeta_nonvanishing_rational hs hpole

#print axioms endpoint_exists
#print axioms zeta_nonvanishing
#print axioms dirichlet_nonvanishing
#print axioms zeta_rational

end QRHV4
