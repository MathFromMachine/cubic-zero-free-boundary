import OAI.NumberTheory.DirichletL.Detector.LowInverseNormalize

/-!
# Source geometry for the 87499/100000 candidate

These are copies of only the geometry-dependent scale lemmas. Generic tuple,
central-shift, product, and Gram inequalities are reused from their original
imports without changing the baseline source.

The scales are X = Z^(17/48), Y = Z^(71869/150000), total slot length at most
12503/75000, and X*Y = Z^(62497/75000). The sixth-power Gram exponent remains
1/6; the resulting square-root exponent is 56249/300000.

This module contains geometry and algebra, not the missing analytic low bound.
-/

namespace OAI
noncomputable section
open scoped Classical
namespace SevenEighths.ProbePhysical.Extension
open CompletedGauss CanonicalQuadraticSieve ProbeRaySlots
local notation "O" => ActualEisensteinCubic.O

lemma source_gram_power (Z δ : ℝ) (hZ : 0<Z) :
    Z^(17/48:ℝ)*(Z^(781/6250:ℝ))^(1/6:ℝ)*(Z^(71869/150000:ℝ))^δ=
      Z^(56249/150000+(71869/150000)*δ:ℝ) := by
  rw [←Real.rpow_mul hZ.le,←Real.rpow_mul hZ.le,←Real.rpow_add hZ,←Real.rpow_add hZ]
  congr 1
  ring

lemma source_gram_sqrt_power (Z δ : ℝ) (hZ : 0<Z) :
    Real.sqrt (Z^(56249/150000+(71869/150000)*δ:ℝ))=Z^(56249/300000+(71869/300000)*δ:ℝ) := by
  rw [Real.sqrt_eq_rpow,←Real.rpow_mul hZ.le]
  congr 1
  ring

lemma source_scale_ratio (Z : ℝ) (hZ : 0<Z) :
    Z^(71869/150000:ℝ)/Z^(17/48:ℝ)=Z^(781/6250:ℝ) := by
  rw [←Real.rpow_sub hZ]
  norm_num

lemma source_scale_square (Z : ℝ) (hZ : 0<Z) :
    Z^(34381/150000:ℝ)*Z^(71869/150000:ℝ)=(Z^(17/48:ℝ))^2 := by
  rw [←Real.rpow_add hZ,←Real.rpow_natCast,←Real.rpow_mul hZ.le]
  norm_num

lemma source_compensated_scale_admissible (q Z L : ℝ) (hq : 1≤q) (hZ : 1≤Z)
    (hL : 1≤L) (hql : q≤Z^(781/6250:ℝ)) (hLl : L≤Z^(34381/150000:ℝ)) :
    1≤Z^(71869/150000:ℝ)/L ∧
    q*Z^(17/48:ℝ)≤Z^(71869/150000:ℝ) ∧
    L*Z^(71869/150000:ℝ)≤q^2*(Z^(17/48:ℝ))^2 := by
  have hz : 0<Z := lt_of_lt_of_le zero_lt_one hZ
  have hl : 0<L := lt_of_lt_of_le zero_lt_one hL
  constructor
  · apply (le_div_iff₀ hl).mpr
    simpa using hLl.trans (Real.rpow_le_rpow_of_exponent_le hZ (show (34381/150000:ℝ)≤71869/150000 by norm_num))
  constructor
  · apply (le_div_iff₀ (Real.rpow_pos_of_pos hz (17/48))).mp
    rwa [source_scale_ratio Z hz]
  · calc
      _≤Z^(34381/150000:ℝ)*Z^(71869/150000:ℝ) := mul_le_mul_of_nonneg_right hLl (by positivity)
      _=(Z^(17/48:ℝ))^2 := source_scale_square Z hz
      _≤_ := le_mul_of_one_le_left (by positivity) (one_le_pow₀ hq)

lemma source_compensated_gram_scale (q Z L δ : ℝ) (hq : 1≤q) (hZ : 1≤Z)
    (hL : 1≤L) (hql : q≤Z^(781/6250:ℝ)) (hLl : L≤Z^(34381/150000:ℝ)) (hδ : 0≤δ) :
    (q*(Z^(17/48:ℝ)/L)*(Z^(71869/150000:ℝ)/L)/(Z^(71869/150000:ℝ)/L))*
      (1+((Z^(71869/150000:ℝ)/L)^2/(q*(Z^(17/48:ℝ)/L)*(Z^(71869/150000:ℝ)/L)))^(1/6:ℝ)+
        ((Z^(71869/150000:ℝ)/L)^2/(q*(Z^(17/48:ℝ)/L)*(Z^(71869/150000:ℝ)/L)))^2/(Z^(71869/150000:ℝ)/L))*
      (Z^(71869/150000:ℝ)/L)^δ ≤
        (3*q/L)*Z^(56249/150000+(71869/150000)*δ:ℝ) := by
  have hz : 0<Z := lt_of_lt_of_le zero_lt_one hZ
  have hq0 : 0<q := lt_of_lt_of_le zero_lt_one hq
  have hL0 : 0<L := lt_of_lt_of_le zero_lt_one hL
  obtain ⟨_,hqp,ht⟩ := source_compensated_scale_admissible q Z L hq hZ hL hql hLl
  have hb := compensated_gram_scale_bound q (Z^(17/48:ℝ)) (Z^(71869/150000:ℝ)) L δ hq0
    (by positivity) (by positivity) hL hδ hqp ht
  apply hb.trans
  have hratio : Z^(71869/150000:ℝ)/(q*Z^(17/48:ℝ))≤Z^(781/6250:ℝ) := by
    rw [←source_scale_ratio Z hz]
    exact div_le_div_of_nonneg_left (by positivity) (by positivity)
      (le_mul_of_one_le_left (by positivity) hq)
  have hp := Real.rpow_le_rpow (by positivity : 0≤Z^(71869/150000:ℝ)/(q*Z^(17/48:ℝ))) hratio (show 0≤(1/6:ℝ) by norm_num)
  calc
    _≤3*(q*Z^(17/48:ℝ)/L)*(Z^(781/6250:ℝ))^(1/6:ℝ)*(Z^(71869/150000:ℝ))^δ := by gcongr
    _=(3*q/L)*(Z^(17/48:ℝ)*(Z^(781/6250:ℝ))^(1/6:ℝ)*(Z^(71869/150000:ℝ))^δ) := by ring
    _=_ := by rw [source_gram_power Z δ hz]

lemma source_compensated_gram_sqrt (q Z L δ : ℝ) (hq : 1≤q) (hZ : 1≤Z)
    (hL : 1≤L) (hql : q≤Z^(781/6250:ℝ)) (hLl : L≤Z^(34381/150000:ℝ)) (hδ : 0≤δ) :
    Real.sqrt ((q*(Z^(17/48:ℝ)/L)*(Z^(71869/150000:ℝ)/L)/(Z^(71869/150000:ℝ)/L))*
      (1+((Z^(71869/150000:ℝ)/L)^2/(q*(Z^(17/48:ℝ)/L)*(Z^(71869/150000:ℝ)/L)))^(1/6:ℝ)+
        ((Z^(71869/150000:ℝ)/L)^2/(q*(Z^(17/48:ℝ)/L)*(Z^(71869/150000:ℝ)/L)))^2/(Z^(71869/150000:ℝ)/L))*
      (Z^(71869/150000:ℝ)/L)^δ) ≤
        Real.sqrt (3*q/L)*Z^(56249/300000+(71869/300000)*δ:ℝ) := by
  apply (Real.sqrt_le_sqrt (source_compensated_gram_scale q Z L δ hq hZ hL hql hLl hδ)).trans_eq
  rw [Real.sqrt_mul (by positivity),source_gram_sqrt_power Z δ (lt_of_lt_of_le zero_lt_one hZ)]

lemma lowGramFactor_source_bound (C : CalibrationData) (Z L δ : ℝ) (hZ : 1≤Z)
    (hL : 1≤L) (hql : elementNorm C.generator≤Z^(781/6250:ℝ))
    (hLl : L≤Z^(34381/150000:ℝ)) (hδ : 0≤δ) :
    lowGramFactor C (Z^(17/48:ℝ)/L) (Z^(71869/150000:ℝ)/L) δ≤
      Real.sqrt (3*elementNorm C.generator/L)*Z^(56249/300000+(71869/300000)*δ:ℝ) :=
  source_compensated_gram_sqrt _ Z L δ (calibration_elementNorm_ge_one C) hZ hL hql hLl hδ

lemma eventually_compensated_source_scales (C : CalibrationData) (B : ℝ) :
    ∀ᶠ Z : ℝ in Filter.atTop,1≤Z ∧ elementNorm C.generator≤Z^(781/6250:ℝ) ∧
      ∀L : ℝ,1≤L→L≤B*Z^(12503/75000:ℝ)→
        1≤Z^(71869/150000:ℝ)/L ∧
        1≤(Z^(71869/150000:ℝ)/L)^2/lowPhysicalScale C (Z^(17/48:ℝ)/L) (Z^(71869/150000:ℝ)/L) ∧
        ∀δ : ℝ,0≤δ→lowGramFactor C (Z^(17/48:ℝ)/L) (Z^(71869/150000:ℝ)/L) δ≤
          Real.sqrt (3*elementNorm C.generator/L)*Z^(56249/300000+(71869/300000)*δ:ℝ) := by
  have hq := (tendsto_rpow_atTop (show 0<(781/6250:ℝ) by norm_num)).eventually
    (Filter.eventually_ge_atTop (elementNorm C.generator))
  have hb := (tendsto_rpow_atTop (show 0<(1/16:ℝ) by norm_num)).eventually
    (Filter.eventually_ge_atTop B)
  filter_upwards [Filter.eventually_ge_atTop (1:ℝ),hq,hb] with Z hZ hq hb
  refine ⟨hZ,hq,?_⟩
  intro L hL hLB
  have hz : 0<Z := lt_of_lt_of_le zero_lt_one hZ
  have hl : 0<L := lt_of_lt_of_le zero_lt_one hL
  have hLl : L≤Z^(34381/150000:ℝ) := calc
    L≤B*Z^(12503/75000:ℝ) := hLB
    _≤Z^(1/16:ℝ)*Z^(12503/75000:ℝ) := mul_le_mul_of_nonneg_right hb (by positivity)
    _=Z^(34381/150000:ℝ) := by rw [←Real.rpow_add hz];norm_num
  obtain ⟨hy,hp,_⟩ := source_compensated_scale_admissible _ Z L (calibration_elementNorm_ge_one C) hZ hL hq hLl
  refine ⟨hy,?_,fun δ hδ=>lowGramFactor_source_bound C Z L δ hZ hL hq hLl hδ⟩
  rw [lowPhysicalScale,compensated_gram_ratio _ _ _ _ (calibration_elementNorm_pos C)
    (by positivity) (by positivity) hl]
  exact (le_div_iff₀ (mul_pos (calibration_elementNorm_pos C) (by positivity))).mpr (by simpa using hp)

lemma lowUnselectedProduct_norm_bound {K : ℕ} (ell : Fin K→ℝ)
    (hell : ∀i,0≤ell i) (hsum : ∑i,ell i≤12503/75000)
    (b Z : ℝ) (hb : 1≤b) (hZ : 1≤Z) (slots : Fin K→Finset O)
    (hslots : ∀i x,x∈slots i→elementNorm x≤b*Z^(ell i))
    (J : Finset (Fin K)) (a : LowUnselectedTuple slots J) :
    elementNorm (∏i : J,(a i).val)≤b^K*Z^(12503/75000:ℝ) := by
  have hz : 0<Z := lt_of_lt_of_le zero_lt_one hZ
  have hsub : ∑i∈J,ell i≤12503/75000 :=
    (Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _) (fun i _ _=>hell i)).trans hsum
  have hc : J.card≤K := by simpa using Finset.card_le_card (Finset.subset_univ J)
  rw [elementNorm_finset_prod]
  calc
    _≤∏i : J,b*Z^(ell i.val) := Finset.prod_le_prod₀ (fun _ _=>by unfold elementNorm;positivity)
      (fun i _=>hslots i.val _ (a i).property)
    _=b^J.card*Z^(∑i∈J,ell i) := by
      rw [Finset.prod_mul_distrib,Finset.prod_const,Finset.card_univ,Fintype.card_coe,
        ←Real.rpow_sum_of_pos hz,Finset.sum_coe_sort]
    _≤b^K*Z^(12503/75000:ℝ) := mul_le_mul (pow_le_pow_right₀ hb hc)
      (Real.rpow_le_rpow_of_exponent_le hZ hsub) (by positivity) (by positivity)

theorem eventually_original_slot_scales {K : ℕ} (C : CalibrationData) (ell : Fin K→ℝ)
    (hell : ∀i,0≤ell i) (hsum : ∑i,ell i≤12503/75000) (b : ℝ) (hb : 1≤b) :
    ∀ᶠ Z : ℝ in Filter.atTop,1≤Z ∧
      ∀(slots : Fin K→Finset O)(_hslots : ∀i x,x∈slots i→x≠0),
      (∀i x,x∈slots i→elementNorm x≤b*Z^(ell i))→
      ∀(J : Finset (Fin K))(a : LowUnselectedTuple slots J),
      let L := elementNorm (∏i : J,(a i).val)
      1≤Z^(71869/150000:ℝ)/L ∧
      1≤(Z^(71869/150000:ℝ)/L)^2/lowPhysicalScale C (Z^(17/48:ℝ)/L) (Z^(71869/150000:ℝ)/L) ∧
      ∀δ : ℝ,0≤δ→lowGramFactor C (Z^(17/48:ℝ)/L) (Z^(71869/150000:ℝ)/L) δ≤
        Real.sqrt (3*elementNorm C.generator/L)*Z^(56249/300000+(71869/300000)*δ:ℝ) := by
  filter_upwards [eventually_compensated_source_scales C (b^K)] with Z hZ
  refine ⟨hZ.1,?_⟩
  intro slots hslots hnorm J a
  exact hZ.2.2 _ (lowUnselectedProduct_norm_ge_one slots hslots J a)
    (lowUnselectedProduct_norm_bound ell hell hsum b Z hb hZ.1 slots hnorm J a)

lemma lowLength_bounds {K : ℕ} (ell : Fin K→ℝ) (hell : ∀i,0≤ell i)
    (hsum : ∑i,ell i≤12503/75000) (J : Finset (Fin K)) :
    0≤lowUnselectedLength ell J ∧ lowUnselectedLength ell J≤12503/75000 ∧
    0≤lowSelectedLength ell J ∧ lowSelectedLength ell J≤12503/75000-lowUnselectedLength ell J := by
  have hu : 0≤lowUnselectedLength ell J := Finset.sum_nonneg (fun i _=>hell i)
  have hs : 0≤lowSelectedLength ell J := Finset.sum_nonneg (fun i _=>hell i.val)
  have he := lowLength_sum ell J
  exact ⟨hu,by linarith,hs,by linarith⟩

lemma lowPhysicalScale_source (C : CalibrationData) (Z L : ℝ) (hZ : 0<Z) :
    lowPhysicalScale C (Z^(17/48:ℝ)/L) (Z^(71869/150000:ℝ)/L)=
      elementNorm C.generator*Z^(62497/75000:ℝ)/L^2 := by
  unfold lowPhysicalScale
  have he : Z^(17/48:ℝ)*Z^(71869/150000:ℝ)=Z^(62497/75000:ℝ) := by rw [←Real.rpow_add hZ];norm_num
  rw [←he]
  ring

lemma lowPhysicalScale_nominal_bound (C : CalibrationData) (Z L c d : ℝ)
    (hZ : 0<Z) (hc : 0<c) (hL : c*Z^d≤L) :
    lowPhysicalScale C (Z^(17/48:ℝ)/L) (Z^(71869/150000:ℝ)/L)≤
      (elementNorm C.generator/c^2)*Z^(62497/75000-2*d:ℝ) := by
  have hl : 0<L := lt_of_lt_of_le (by positivity) hL
  rw [lowPhysicalScale_source C Z L hZ]
  calc
    _≤elementNorm C.generator*Z^(62497/75000:ℝ)/(c*Z^d)^2 :=
      div_le_div_of_nonneg_left (by unfold elementNorm;positivity) (by positivity)
        (pow_le_pow_left₀ (by positivity) hL 2)
    _=_ := by
      have hp : (Z^d)^2=Z^(2*d) := by
        rw [←Real.rpow_natCast,←Real.rpow_mul hZ.le]
        congr 1
        push_cast
        ring
      rw [mul_pow,hp,Real.rpow_sub hZ]
      ring

lemma low_inverse_power_cancel (Z d α : ℝ) (hZ : 0<Z) :
    Z^(62497/75000-2*d+α)*(Z^d)^2/Z^(62497/75000:ℝ)=Z^α := by
  have hp : (Z^d)^2=Z^(2*d) := by
    rw [←Real.rpow_natCast,←Real.rpow_mul hZ.le]
    congr 1
    push_cast
    ring
  rw [hp,←Real.rpow_add hZ,←Real.rpow_sub hZ]
  congr 1
  ring

lemma low_inverse_sqrt_normalized (q C B Z L d α H E : ℝ) (n : ℕ)
    (hq : 0<q) (hC : 0≤C) (_hB : 0≤B) (hZ : 0<Z) (hL : 0<L) (hH : 1≤H)
    (hE : 0≤E) (hEL : E≤C*H^n*Z^(62497/75000-2*d+α)) (hLB : L≤B*Z^d) :
    Real.sqrt E/Real.sqrt (q*Z^(62497/75000:ℝ)/L^2)≤
      Real.sqrt (C*B^2/q)*H^n*Z^(α/2) := by
  have hratio : E/(q*Z^(62497/75000:ℝ)/L^2)≤(C*B^2/q)*H^n*Z^α := by
    calc
      _≤(C*H^n*Z^(62497/75000-2*d+α))/(q*Z^(62497/75000:ℝ)/L^2) :=
        div_le_div_of_nonneg_right hEL (by positivity)
      _=(C*H^n*Z^(62497/75000-2*d+α))*L^2/(q*Z^(62497/75000:ℝ)) := by field_simp
      _≤(C*H^n*Z^(62497/75000-2*d+α))*(B*Z^d)^2/(q*Z^(62497/75000:ℝ)) := by
        gcongr
      _=(C*B^2/q)*H^n*(Z^(62497/75000-2*d+α)*(Z^d)^2/Z^(62497/75000:ℝ)) := by ring
      _=_ := by rw [low_inverse_power_cancel Z d α hZ]
  rw [←Real.sqrt_div hE]
  apply (Real.sqrt_le_sqrt hratio).trans
  rw [Real.sqrt_mul (by positivity),Real.sqrt_mul (by positivity)]
  have hp : Real.sqrt (Z^α)=Z^(α/2) := by
    rw [Real.sqrt_eq_rpow,←Real.rpow_mul hZ.le]
    congr 1
    ring
  rw [hp]
  exact mul_le_mul_of_nonneg_right
    (mul_le_mul_of_nonneg_left (Real.sqrt_le_self_iff.mpr (Or.inr (one_le_pow₀ hH))) (by positivity)) (by positivity)

#print axioms source_compensated_gram_sqrt
#print axioms eventually_original_slot_scales
#print axioms low_inverse_sqrt_normalized

end SevenEighths.ProbePhysical.Extension
end
end OAI
