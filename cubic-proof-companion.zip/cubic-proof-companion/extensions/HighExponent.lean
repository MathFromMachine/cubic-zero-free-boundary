import OAI.NumberTheory.DirichletL.Detector.CentralMixedMargins
import OAI.NumberTheory.DirichletL.PrimeRows.NonfloorExponent

/-! Actual central-exponent arithmetic for the fixed .87499 geometry.
The amplification slope remains 5/6. This module does not posit row counts:
it proves the consequences of the same explicit count bounds as the source. -/

namespace OAI
noncomputable section
namespace SevenEighths.ProbeCentralExponent.Extension

def sourceExponent (a d R q : ℝ) : ℝ :=
  (17/48)*(1/2-17/50)+a+17/50-1-a*(71869/150000)-d*(17/50)+d*R+
    d*(a-1/2)+(12503/75000)*(17/50-1/2+q)

def relativeExponent (δ d R q : ℝ) : ℝ :=
  -2079/100000+(50003/75000)*δ+(12503/75000)*q-(40627/50000)*(1-R)+
    (d-40627/50000)*(R+δ/2-17/50)

lemma original_exponent_identity (a d R q : ℝ) :
    sourceExponent a d R q=56249/300000+relativeExponent (2*a-1) d R q := by
  unfold sourceExponent relativeExponent
  ring

lemma endpoint_perturbation (δ R q : ℝ) :
    relativeExponent δ (40627/50000) R q =
      ProbeCentralExponent.relativeExponent δ (13/16) R q+
        (4/100000)*(1/12+δ+R+q) := by
  unfold relativeExponent ProbeCentralExponent.relativeExponent
  ring

lemma balanced_row_bounds (δ x : ℝ)
    (hδ : 0≤δ) (hδ1 : δ≤5/6) (hx : 0≤x) (hx1 : x≤1/2) :
    1-δ≤Endpoint.balancedRowCount δ (1/2-x) ∧
      Endpoint.balancedRowCount δ (1/2-x)≤17/12-(3/2)*δ := by
  have ht := HeckeDetectorRowCount.balanced_cutoff_bounds hδ hδ1 hx hx1
  have ha : 0≤5/6-δ := by linarith
  have hlo := mul_le_mul_of_nonneg_left ht.1 ha
  have hhi := mul_le_mul_of_nonneg_left ht.2 ha
  unfold Endpoint.balancedRowCount
  constructor <;> nlinarith

lemma balanced_endpoint_margin (δ x : ℝ)
    (hδ : 0≤δ) (hδ1 : δ≤5/6) (hx : 0≤x) (hx1 : x≤1/2) :
    relativeExponent δ (40627/50000)
      (Endpoint.balancedRowCount δ (1/2-x)) (δ*x) ≤ -(1/20000:ℝ) := by
  have hb := Endpoint.balanced_endpoint_margin hδ hδ1
    (show 0≤1/2-x by linarith) (show 1/2-x≤1/2 by linarith)
  have hr := (balanced_row_bounds δ x hδ hδ1 hx hx1).2
  have hq := mul_le_mul_of_nonneg_left hx1 hδ
  have hi := endpoint_perturbation δ (Endpoint.balancedRowCount δ (1/2-x)) (δ*x)
  unfold Endpoint.balancedExponent at hb
  unfold ProbeCentralExponent.relativeExponent at hi
  linarith

lemma frequency_slope_bounds (δ R : ℝ) (_hδ : 0≤δ) (hδ1 : δ≤1)
    (hRlo : 1-δ≤R) (hRhi : R≤139/96) :
    4/25≤R+δ/2-17/50 ∧ R+δ/2-17/50≤2 := by
  constructor <;> linarith

lemma relative_extend (δ d R q ζ : ℝ) (hζ : 0≤ζ) (hd : d≤40627/50000+ζ)
    (hslo : 0≤R+δ/2-17/50) (hshi : R+δ/2-17/50≤2) :
    relativeExponent δ d R q≤relativeExponent δ (40627/50000) R q+2*ζ := by
  have hh := mul_le_mul_of_nonneg_right (show d-40627/50000≤ζ by linarith) hslo
  have hh' := mul_le_mul_of_nonneg_left hshi hζ
  unfold relativeExponent
  nlinarith

lemma balanced_source_margin (δ x R Δ loss ζ d : ℝ)
    (hδ : 0≤δ) (hδ1 : δ≤5/6) (hx : 0≤x) (hx1 : x≤1/2)
    (hR : R≤Endpoint.balancedRowCount δ (1/2-x)+Δ/4+loss)
    (hζ : 0≤ζ) (hd : d≤40627/50000+ζ)
    (hslo : 0≤R+δ/2-17/50) (hshi : R+δ/2-17/50≤2) :
    sourceExponent ((1+δ)/2) d R (δ*x)-(56249/300000+Δ)≤
      -1/20000-(159373/200000)*Δ+(40627/50000)*loss+2*ζ := by
  have hb := balanced_endpoint_margin δ x hδ hδ1 hx hx1
  have he := relative_extend δ d R (δ*x) ζ hζ hd hslo hshi
  rw [original_exponent_identity]
  have hid : 2*((1+δ)/2)-1=δ := by ring
  rw [hid]
  unfold relativeExponent at hb he ⊢
  nlinarith

lemma high_source_margin (δ R q Δ loss ζ d : ℝ)
    (hq : q≤δ/2) (hR : R≤1-δ+loss)
    (hζ : 0≤ζ) (hd : d≤40627/50000+ζ)
    (hslo : 0≤R+δ/2-17/50) (hshi : R+δ/2-17/50≤2) :
    sourceExponent ((1+δ)/2) d R q-(56249/300000+Δ)≤
      -2079/100000-(781/12500)*δ-Δ+(40627/50000)*loss+2*ζ := by
  have he := relative_extend δ d R q ζ hζ hd hslo hshi
  rw [original_exponent_identity]
  have hid : 2*((1+δ)/2)-1=δ := by ring
  rw [hid]
  unfold relativeExponent at he ⊢
  nlinarith

lemma floor_source_margin (q Δ ζ d : ℝ) (hq : q≤1/100)
    (hζ : 0≤ζ) (hd : d≤40627/50000+ζ) :
    sourceExponent (51/100) d 1 q-(56249/300000+Δ)≤-1809/312500-Δ+2*ζ := by
  have he := relative_extend (1/50) d 1 q ζ hζ hd (by norm_num) (by norm_num)
  rw [original_exponent_identity]
  norm_num only at *
  unfold relativeExponent at he ⊢
  nlinarith

lemma intermediate_source_margin (δ q Δ d : ℝ) (_hδ : 0≤δ) (hδ1 : δ≤5/6)
    (hq : q≤δ/2) (hd : d≤1/2) :
    sourceExponent ((1+δ)/2) d (76/75-(2/3)*δ) q-(56249/300000+Δ)≤
      -150863/45000000-Δ := by
  have hs : 0≤(76/75-(2/3)*δ)+δ/2-17/50 := by linarith
  have hm := mul_le_mul_of_nonneg_right hd hs
  unfold sourceExponent
  nlinarith

def realLoss (N : ℕ) (d e eps heightLoss mesh : ℝ) : ℝ :=
  (328131/25000)*e+12*d*e+d*eps*(N+8)+heightLoss+(12503/75000)*mesh

lemma realLoss_bound (N : ℕ) (d e eps heightLoss mesh : ℝ)
    (hd : d≤1) (he : 0≤e) (heps : 0≤eps) :
    realLoss N d e eps heightLoss mesh≤
      26*e+(N+8)*eps+heightLoss+(12503/75000)*mesh := by
  have h1 := mul_le_mul_of_nonneg_right hd he
  have h2 := mul_le_mul_of_nonneg_right hd (show 0≤eps*(N+8) by positivity)
  unfold realLoss
  nlinarith

lemma physical_scale_identity (Z a e : ℝ) (hZ : 0<Z) :
    (Z^(17/48:ℝ))^(4/25:ℝ)*Z^(a+16*e-33/50)*(Z^(71869/150000:ℝ))^(-a-6*e)=
      Z^((78131/150000)*a-181/300+(328131/25000)*e) := by
  rw [←Real.rpow_mul hZ.le,←Real.rpow_mul hZ.le,←Real.rpow_add hZ,←Real.rpow_add hZ]
  congr 1
  ring

lemma signal_exponent (β : ℝ) :
    β-25781/37500 = 56249/300000+(β-87499/100000) := by ring

lemma bootstrap_gap_bounds (β : ℝ) (hβ : 87499/100000<β) (hβold : β≤7/8) :
    0<β-87499/100000 ∧ β-87499/100000≤1/100000 ∧
      β≤(1+(3/4+2*(β-87499/100000)))/2 := by
  constructor
  · linarith
  constructor <;> linarith

#print axioms balanced_endpoint_margin
#print axioms balanced_source_margin
#print axioms floor_source_margin
#print axioms intermediate_source_margin
#print axioms physical_scale_identity

end SevenEighths.ProbeCentralExponent.Extension
end
end OAI

/- Adapted arithmetic from Detector/CentralDyadicWeight.lean. -/

namespace OAI

noncomputable section
open scoped Classical BigOperators
namespace SevenEighths.ProbeHighRowFamily.Extension
open HeckeFamily HeckeInverseAmplification ProbePhysical

lemma dyadic_weighted_rows_card (α r C U B : ℝ) (hC : 0≤C) (hU : 0<U)
    (R : Finset FreeRow) (hcard : (R.card:ℝ)≤B)
    (hR : ∀u∈R,U≤rowNorm u ∧ rowNorm u≤2*U)
    (F : FreeRow→ℝ) (hF : ∀u∈R,F u≤C*rowNorm u^α)
    (z : ℂ) (hz : z.re=r) :
    (∑u∈R,‖frequencyWeight z ⟨u.val,u.property.1⟩‖*F u)≤
      B*C*ProbeSelectedPrimeSums.annularPower 1 2 (α-r)*U^(α-r) := by
  have hA := ProbeSelectedPrimeSums.annularPower_nonneg 1 2 (α-r) (by norm_num)
  calc
    _ ≤ ∑u∈R,C*ProbeSelectedPrimeSums.annularPower 1 2 (α-r)*U^(α-r) := by
      apply Finset.sum_le_sum
      intro u hu
      have hN : 0<rowNorm u := hU.trans_le (hR u hu).1
      rw [frequencyWeight_ideal_norm,hz]
      change rowNorm u^(-r)*F u≤_
      calc
        _ ≤ rowNorm u^(-r)*(C*rowNorm u^α) :=
          mul_le_mul_of_nonneg_left (hF u hu) (Real.rpow_nonneg hN.le _)
        _ = C*rowNorm u^(α-r) := by
          rw [show α-r=(-r)+α by ring,Real.rpow_add hN]; ring
        _ ≤ _ := by
          have hb := ProbeSelectedPrimeSums.annular_rpow 1 2 U (rowNorm u) (α-r)
            (by norm_num) (by norm_num) hU (by simpa using (hR u hu).1) (hR u hu).2
          simpa only [mul_assoc] using mul_le_mul_of_nonneg_left hb hC
    _ = (R.card:ℝ)*(C*ProbeSelectedPrimeSums.annularPower 1 2 (α-r)*U^(α-r)) := by simp
    _ ≤ B*(C*ProbeSelectedPrimeSums.annularPower 1 2 (α-r)*U^(α-r)) :=
      mul_le_mul_of_nonneg_right hcard (by positivity)
    _ = _ := by ring

lemma annular_power_uniform (p pmax : ℝ) (hp : p≤pmax) :
    ProbeSelectedPrimeSums.annularPower 1 2 p≤max 1 ((2:ℝ)^pmax) := by
  unfold ProbeSelectedPrimeSums.annularPower
  rw [Real.one_rpow]
  exact max_le_max le_rfl (Real.rpow_le_rpow_of_exponent_le (by norm_num) hp)

def mixedSourceExponent (a v d R q : ℝ) : ℝ :=
  ProbeCentralExponent.Extension.sourceExponent a v R q+(d-v)*R

lemma mixed_physical_exponent (Z a v d R q e eps loss mesh : ℝ) (N : ℕ)
    (hZ : 0<Z) :
    ((Z^(17/48:ℝ))^(4/25:ℝ)*Z^(a+16*e-33/50)*(Z^(71869/150000:ℝ))^(-a-6*e))*
      ((Z^d)^R*(Z^v)^(a-1/2+12*e+eps*(N+8)-17/50)*Z^(-12503/468750+(12503/75000)*q+(12503/75000)*mesh+loss))=
    Z^(mixedSourceExponent a v d R q+ProbeCentralExponent.Extension.realLoss N v e eps loss mesh) := by
  rw [ProbeCentralExponent.Extension.physical_scale_identity Z a e hZ]
  simp_rw [←Real.rpow_mul hZ.le]
  rw [←Real.rpow_add hZ,←Real.rpow_add hZ,←Real.rpow_add hZ]
  congr 1
  unfold mixedSourceExponent ProbeCentralExponent.Extension.sourceExponent ProbeCentralExponent.Extension.realLoss
  ring

lemma mixed_source_slack (a v d R q μ Rmax : ℝ)
    (hR : 0≤R) (hRmax : R≤Rmax) (hμ : 0≤μ) (hd : d-v≤μ) :
    mixedSourceExponent a v d R q≤ProbeCentralExponent.Extension.sourceExponent a v R q+μ*Rmax := by
  have h1 := mul_le_mul_of_nonneg_right hd hR
  have h2 := mul_le_mul_of_nonneg_left hRmax hμ
  unfold mixedSourceExponent
  linarith

lemma dyad_conductor_margin (Z v margin : ℝ) (hZ : 0<Z) (hmargin : 2≤Z^margin)
    (R : Finset FreeRow) (hR : ∀u∈R,rowNorm u≤2*Z^v) :
    ∀u∈R,rowNorm u≤Z^((v+2*margin)-margin) := by
  intro u hu
  calc
    rowNorm u≤2*Z^v := hR u hu
    _ ≤ Z^margin*Z^v := mul_le_mul_of_nonneg_right hmargin (Real.rpow_nonneg hZ.le _)
    _ = _ := by rw [←Real.rpow_add hZ]; congr 1; ring
end SevenEighths.ProbeHighRowFamily.Extension

end

end OAI

/- Adapted arithmetic from Detector/CentralMixedMargins.lean. -/

namespace OAI

noncomputable section
namespace SevenEighths.ProbeHighRowFamily.Extension
open HeckeDetectorRowCount ProbeCentralExponent.Extension

lemma balanced_count_range (δ x Δ loss : ℝ) (hδ : 0≤δ) (hd : δ≤5/6)
    (hx : 0≤x) (hx' : x≤1/2) (hΔ : 0≤Δ) (hΔ' : Δ≤1/8)
    (hl : 0≤loss) (hl' : loss≤1/32) :
    let R := Endpoint.balancedRowCount δ (1/2-x)+Δ/4+loss
    1-δ≤R ∧ R≤3/2 := by
  have ht := balanced_cutoff_bounds hδ hd hx hx'
  have hp0 := mul_nonneg (show 0≤5/6-δ by linarith) (show 0≤Endpoint.balancedCutoff δ (1/2-x)-1 by linarith)
  have hp1 := mul_le_mul_of_nonneg_left ht.2 (show 0≤5/6-δ by linarith)
  dsimp only
  unfold Endpoint.balancedRowCount
  constructor <;> nlinarith

lemma balanced_mixed_margin (δ x Δ loss ζ μ v d : ℝ)
    (hδ : 0≤δ) (hd : δ≤5/6) (hx : 0≤x) (hx' : x≤1/2)
    (hΔ : 0≤Δ) (hΔ' : Δ≤1/8) (hl : 0≤loss) (hl' : loss≤1/32)
    (hζ : 0≤ζ) (hv : v≤40627/50000+ζ) (hμ : 0≤μ) (hdv : d-v≤μ) :
    let R := Endpoint.balancedRowCount δ (1/2-x)+Δ/4+loss
    mixedSourceExponent ((1+δ)/2) v d R (δ*x)-(56249/300000+Δ)≤
      -1/20000-(159373/200000)*Δ+(40627/50000)*loss+2*ζ+(3/2)*μ := by
  dsimp only
  let R := Endpoint.balancedRowCount δ (1/2-x)+Δ/4+loss
  have hr := balanced_count_range δ x Δ loss hδ hd hx hx' hΔ hΔ' hl hl'
  have hlo : 0≤R+δ/2-17/50 := by dsimp [R]; linarith [hr.1]
  have hhi : R+δ/2-17/50≤2 := by dsimp [R]; linarith [hr.2]
  have hm := balanced_source_margin δ x R Δ loss ζ v hδ hd hx hx' le_rfl hζ hv hlo hhi
  have hs := mixed_source_slack ((1+δ)/2) v d R (δ*x) μ (3/2)
    (by dsimp [R];linarith [hr.1]) hr.2 hμ hdv
  linarith

lemma high_mixed_margin (δ q Δ loss ζ μ v d : ℝ)
    (hδ : 5/6≤δ) (hd : δ≤1) (hq : q≤δ/2)
    (hl : 0≤loss) (hl' : loss≤1/32)
    (hζ : 0≤ζ) (hv : v≤40627/50000+ζ) (hμ : 0≤μ) (hdv : d-v≤μ) :
    mixedSourceExponent ((1+δ)/2) v d (1-δ+loss) q-(56249/300000+Δ)≤
      -2079/100000-(781/12500)*δ-Δ+(40627/50000)*loss+2*ζ+μ := by
  have hlo : 0≤(1-δ+loss)+δ/2-17/50 := by linarith
  have hhi : (1-δ+loss)+δ/2-17/50≤2 := by linarith
  have hm := high_source_margin δ (1-δ+loss) q Δ loss ζ v hq le_rfl hζ hv hlo hhi
  have hs := mixed_source_slack ((1+δ)/2) v d (1-δ+loss) q μ 1
    (by linarith) (by linarith) hμ hdv
  linarith

lemma balanced_mixed_saving (δ x Δ loss ζ μ v d other saving : ℝ)
    (hδ : 0≤δ) (hd : δ≤5/6) (hx : 0≤x) (hx' : x≤1/2)
    (hΔ : 0≤Δ) (hΔ' : Δ≤1/8) (hl : 0≤loss) (hl' : loss≤1/32)
    (hζ : 0≤ζ) (hv : v≤40627/50000+ζ) (hμ : 0≤μ) (hdv : d-v≤μ)
    (hbudget : (40627/50000)*loss+2*ζ+(3/2)*μ+other+saving≤1/20000) :
    mixedSourceExponent ((1+δ)/2) v d
      (Endpoint.balancedRowCount δ (1/2-x)+Δ/4+loss) (δ*x)+other≤56249/300000+Δ-saving := by
  have hm := balanced_mixed_margin δ x Δ loss ζ μ v d hδ hd hx hx' hΔ hΔ' hl hl' hζ hv hμ hdv
  linarith
end SevenEighths.ProbeHighRowFamily.Extension

end

end OAI

/- Adapted arithmetic from PrimeRows/NonfloorExponent.lean. -/

namespace OAI

noncomputable section
namespace SevenEighths.ProbeHighRowFamily.Extension

lemma adaptive_mixed_saving (N : ℕ) (a q Δ ε εm slotMesh ν ζ μ v d e eps loss mesh overhead saving : ℝ)
    (ha : 1/2<a) (ha' : a≤1) (hq : 0≤q) (hq' : q≤(2*a-1)/2)
    (hΔ : 0≤Δ) (hΔ' : Δ≤1/8) (hε : 0≤ε) (hεm : 0≤εm)
    (hslot : 0≤slotMesh) (hν : 0≤ν)
    (hcount : 159*ε+εm+slotMesh+7*ν≤1/32)
    (hζ : 0≤ζ) (hζ' : ζ≤9373/50000) (hv : v≤40627/50000+ζ)
    (hμ : 0≤μ) (hdv : d-v≤μ) (he : 0≤e) (heps : 0≤eps)
    (hbudget : (40627/50000)*(159*ε+εm+slotMesh+7*ν)+2*ζ+(3/2)*μ+
      (26*e+(N+8)*eps+loss+(12503/75000)*mesh)+overhead+saving≤1/20000) :
    mixedSourceExponent a v d (adaptiveRowExponent (2*a-1) q Δ ε εm slotMesh ν) q+
      ProbeCentralExponent.Extension.realLoss N v e eps loss mesh+overhead≤56249/300000+Δ-saving := by
  have hδ : 0<2*a-1 := by linarith
  have hx : 0≤q/(2*a-1) := div_nonneg hq hδ.le
  have hx' : q/(2*a-1)≤1/2 := (div_le_iff₀ hδ).mpr (by linarith)
  have hl : 0≤159*ε+εm+slotMesh+7*ν := by positivity
  have haeq : (1+(2*a-1))/2=a := by ring
  have hqeq : (2*a-1)*(q/(2*a-1))=q := mul_div_cancel₀ q hδ.ne'
  have hr := ProbeCentralExponent.Extension.realLoss_bound N v e eps loss mesh (by linarith) he heps
  by_cases hd : 2*a-1≤5/6
  · have hb := balanced_mixed_saving (2*a-1) (q/(2*a-1)) Δ (159*ε+εm+slotMesh+7*ν)
      ζ μ v d (ProbeCentralExponent.Extension.realLoss N v e eps loss mesh+overhead) saving
      hδ.le hd hx hx' hΔ hΔ' hl hcount hζ hv hμ hdv (by linarith)
    rw [haeq,hqeq] at hb
    simpa only [adaptiveRowExponent,ite_eq_left hd,add_assoc] using hb
  · have hhl : 0≤78*ε+εm := by positivity
    have hh := high_mixed_margin (2*a-1) q Δ (78*ε+εm) ζ μ v d
      (le_of_lt (lt_of_not_ge hd)) (by linarith) hq' hhl (by linarith)
      hζ hv hμ hdv
    rw [haeq] at hh
    simp only [adaptiveRowExponent,ite_eq_right hd]
    simp only [add_assoc] at hh ⊢
    linarith

lemma central_class_exponent_identity (N : ℕ) (a v d R q e eps loss mesh overhead : ℝ) :
    ((78131/150000)*a-181/300+(328131/25000)*e)+
      (overhead+d*R+v*(a-1/2+12*e+eps*(N+8)-17/50)+loss-12503/468750+(12503/75000)*q+(12503/75000)*mesh)=
    mixedSourceExponent a v d R q+ProbeCentralExponent.Extension.realLoss N v e eps loss mesh+overhead := by
  unfold mixedSourceExponent ProbeCentralExponent.Extension.sourceExponent ProbeCentralExponent.Extension.realLoss
  ring

end SevenEighths.ProbeHighRowFamily.Extension

end

end OAI

#print axioms OAI.SevenEighths.ProbeHighRowFamily.Extension.adaptive_mixed_saving
