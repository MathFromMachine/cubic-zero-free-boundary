import DetectorEnergy

namespace OAI
noncomputable section
open scoped Classical
namespace SevenEighths.ProbePhysical.Extension
open CompletedGauss CanonicalQuadraticSieve RayFourExpansion InverseReflectedPhase.Extension
local notation "O" => ActualEisensteinCubic.O
local notation "Id" => Ideal O

theorem low_physical_inverse_normalized_compensated (η : HeckeFamily.Character) (S : Finset Id)
    (hS : ∀P∈S,P.IsMaximal) (hbad : fixedBadPrimes⊆S)
    {K : ℕ} (ell : Fin K→ℝ) (hell : ∀i,0≤ell i) (hsum : ∑i,ell i≤12503/75000)
    (a b aCut bCut ε : ℝ) (ha : 0<a) (haCut : 0<aCut) (hbCut : 0<bCut)
    (hε : 0<ε) (hε1 : ε≤1) :
    ∃degree : ℕ,∃C : ℝ,0<C ∧ ∀ᶠZ : ℝ in Filter.atTop,1<Z ∧
    ∀(T : Fin K→Finset PrimeIdeal),(∀i P,P∈T i→Supported P.val)→
      (∀i P,P∈T i→P.val∉S)→Pairwise (fun i j=>Disjoint (T i) (T j))→
      (∀i P,P∈T i→a*Z^(ell i)≤(Ideal.absNorm P.val:ℝ) ∧ (Ideal.absNorm P.val:ℝ)≤b*Z^(ell i))→
    ∀(J : Finset (Fin K))(p : LowUnselectedTuple (fun i=>canonicalSlotSupport (T i)) J),
    ∀X : ℝ,0<X→Z^(1+lowSelectedLength ell J-ε/2)≤X→X≤Z^(1+lowSelectedLength ell J+ε/2)→
    ∀(W : Fin K→ℝ→ℂ),(∀i x,‖W i x‖≤1)→∀t : ℝ,
      let L := elementNorm (∏i : J,(p i).val)
      let Q := lowPhysicalScale (calibrationForSet S hS) (Z^(17/48:ℝ)/L) (Z^(71869/150000:ℝ)/L)
      ∀(hX0 : 0<Z^(17/48:ℝ)/L)(hY0 : 0<Z^(71869/150000:ℝ)/L),
      (Real.sqrt Q)⁻¹/(2*Real.pi)*
        lowInverseMass (calibrationForSet S hS) aCut bCut haCut hbCut
          (Z^(17/48:ℝ)/L) (Z^(71869/150000:ℝ)/L) hX0 hY0
          (lowSelectedInverseRow Finset.univ
            (lowSelectedWeight η (fun i=>canonicalSlotSupport (T i)) J W (fun i=>Z^(ell i)) t)
            η S hS (lowSelectedIdeal (fun i=>canonicalSlotSupport (T i)) J) X t)≤
        C*(1+‖t‖)^degree*Z^(507*ε/2)*L^(1/8:ℝ) := by
  obtain ⟨degree,C,hC,he⟩ := low_physical_inverse_normalized η S hS hbad ell hell hsum
    a b aCut bCut ε ha haCut hbCut hε hε1
  let c := (min 1 a)^K
  have hc : 0<c := by dsimp [c]; positivity
  let C0 := C*c^(-(1/8:ℝ))
  refine ⟨degree,C0,by dsimp [C0]; positivity,?_⟩
  filter_upwards [he] with Z hZ
  refine ⟨hZ.1,?_⟩
  intro T hT hout hdis hnorm J p X hX hXlo hXhi W hW t
  dsimp only
  intro hX0 hY0
  let L := elementNorm (∏i : J,(p i).val)
  let d := lowUnselectedLength ell J
  have hz : 0<Z := lt_trans zero_lt_one hZ.1
  have hL : 0<L := lowUnselectedProduct_norm_pos _
    (fun i n hn=>canonicalSlotSupport_nonzero _ (hT i) n hn) J p
  have hnormE (i : Fin K) (n : O) (hn : n∈canonicalSlotSupport (T i)) :
      a*Z^(ell i)≤elementNorm n := by
    obtain ⟨P,hP,rfl⟩ := Finset.mem_image.mp hn
    rw [primaryTuple_norm P (hT i P hP)]
    exact (hnorm i P hP).1
  have hLlo : c*Z^d≤L :=
    lowUnselectedProduct_norm_lower ell a Z ha hz _ hnormE J p
  have hd : 0≤d := (lowLength_bounds ell hell hsum J).1
  have hr : rowLoss d≤d/4 := by
    unfold rowLoss
    have hm : max 0 (5*(12503/75000:ℝ)+d-1)≤d := max_le hd (by linarith)
    linarith
  have haLoss := row_loss_absorbed Z L c d (rowLoss d) hZ.1.le hc hL hLlo hr
  have hraw := hZ.2 T hT hout hdis hnorm J p X hX hXlo hXhi W hW t hX0 hY0
  apply hraw.trans
  change C*(1+‖t‖)^degree*Z^((rowLoss d+507*ε)/2)≤
    C0*(1+‖t‖)^degree*Z^(507*ε/2)*L^(1/8:ℝ)
  calc
    _=C*(1+‖t‖)^degree*(Z^(rowLoss d/2)*Z^(507*ε/2)) := by
      rw [←Real.rpow_add hz]
      congr 2
      congr 1
      ring
    _≤C*(1+‖t‖)^degree*((c^(-(1/8:ℝ))*L^(1/8:ℝ))*Z^(507*ε/2)) := by
      gcongr
    _=_ := by dsimp [C0]; ring

#print axioms low_physical_inverse_normalized_compensated
end SevenEighths.ProbePhysical.Extension
end
end OAI
