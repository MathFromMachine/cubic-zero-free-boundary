import PhysicalProbe
import Normalizer

/-!
# The actual normalized low estimate at the candidate geometry

The raw estimate is supplied by the generalized physical-probe proof. It is
not assumed as an extra hypothesis. Normalization uses the unchanged actual
principal scalar with the new total slot length 12503/75000.

This low estimate alone does not establish a zero-free region.
-/

namespace QRHExtension.LowProof

noncomputable section
open scoped Classical BigOperators Topology ContDiff
open Filter Asymptotics
open OAI.SevenEighths
open HeckeFamily ProbePhysical ProbeRaySlots PrincipalSignalComparison
open PrincipalMellinResidues ProbePrincipalResidueActual
local notation "O" => HeckeFamily.O

/-- Low estimate for the actual compensated physical probe divided by its
actual ray-prime residue normalizer at the 87499/100000 candidate geometry. -/
theorem candidate_normalized_low {K : ℕ}
    (M : Ideal O) [NeZero M] [Finite (O ⧸ M)]
    (H : Subgroup (O ⧸ M)ˣ) (hH : RayOrthogonality.globalUnits M ≤ H)
    (S : Finset (Ideal O)) (hS : SourceExclusions S) (hmax : ∀ P ∈ S, P.IsMaximal)
    (a b B loss : ℝ) (ha : 0 < a) (hab : a ≤ b) (hloss : 0 < loss)
    (ell : Fin K → ℝ) (hell : ∀ j, 0 < ell j) (hinj : Function.Injective ell)
    (hsum : ∑ j, ell j = 12503 / 75000)
    (W : Fin K → ℝ → ℝ) (hW : ∀ j, ContDiff ℝ ∞ (W j))
    (hcompact : ∀ j, HasCompactSupport (W j))
    (hsupp : ∀ j, Function.support (W j) ⊆ Set.Ioo a b)
    (hWB : ∀ j y, 0 ≤ W j y ∧ W j y ≤ B) (hne : ∀ j, W j ≠ 0)
    (W0 W1 : SchwartzMap ℝ ℂ) (a0 b0 a1 b1 : ℝ)
    (ha0 : 0 < a0) (ha1 : 0 < a1)
    (hW0 : Function.support W0 ⊆ Set.Icc a0 b0)
    (hW1 : Function.support W1 ⊆ Set.Icc a1 b1)
    (hr0 : ∀ y, (W0 y).im = 0) (hr1 : ∀ y, (W1 y).im = 0)
    (hp0 : ∀ y, 0 ≤ (W0 y).re) (hp1 : ∀ y, 0 ≤ (W1 y).re)
    (hn0 : W0 ≠ 0) (hn1 : W1 ≠ 0) :
    letI : NeZero (∏ P ∈ S, P) := ⟨fixedPrimeProduct_ne_zero S hS.prime⟩
    ∀ η : Character,
      normalizedProbe M H S hmax ell (12503 / 75000) a b (17 / 48)
        (71869 / 150000) W W0 W1 η =O[atTop]
        (fun Z : ℝ => Z ^ (56249 / 300000 + loss)) := by
  let WC : Fin K → ℝ → ℂ := fun j y => (W j y : ℂ)
  have hWC (j : Fin K) : Function.support (WC j) ⊆ Set.Icc a b := by
    intro y hy
    apply Set.Ioo_subset_Icc_self (hsupp j _)
    intro hz
    exact hy (by dsimp [WC]; rw [hz]; simp)
  have hWCB (j : Fin K) (y : ℝ) : ‖WC j y‖ ≤ B := by
    simpa only [WC, Complex.norm_real, Real.norm_eq_abs,
      abs_of_nonneg (hWB j y).1] using (hWB j y).2
  have hW1' : Function.support W1 ⊆ Set.Icc a1 (max b1 (a1 + 1)) := by
    intro y hy
    exact ⟨(hW1 hy).1, (hW1 hy).2.trans (le_max_left _ _)⟩
  have hab1 : a1 < max b1 (a1 + 1) :=
    lt_of_lt_of_le (by linarith) (le_max_right _ _)
  have hraw : ∀ η : Character, ∃ Cp : ℝ, 0 < Cp ∧ ∀ᶠ Z : ℝ in atTop,
      ‖unnormalizedProbe M H S hmax ell a b (17 / 48) (71869 / 150000)
        W W0 W1 η Z‖ ≤ Cp * Z ^ (56249 / 300000 + loss / 2) := by
    intro η
    simpa only [unnormalizedProbe, WC] using
      (OAI.SevenEighths.ProbePhysical.Extension.original_ray_compensatedPhysicalProbe_low_loss
        S hS hmax ell (fun j => (hell j).le) hinj hsum.le
        (RayQuotient.identityClass M H) a b B (loss / 2) ha hab (by positivity)
        WC hWC hWCB W0 W1 a0 b0 a1 (max b1 (a1 + 1))
        (SchwartzMap.seminorm ℝ 0 0 W0) (SchwartzMap.seminorm ℝ 0 0 W1)
        ha0 ha1 hab1 (by positivity) (by positivity) hW0 hW1'
        (W0.smooth (⊤ : ℕ∞)) (W1.smooth (⊤ : ℕ∞))
        (SchwartzMap.norm_le_seminorm ℝ W0) (SchwartzMap.norm_le_seminorm ℝ W1) η)
  exact normalizedProbe_low_of_unnormalized M H hH S hS hmax
    a b (17 / 48) (71869 / 150000) (56249 / 300000) loss ha hab hloss
    ell (12503 / 75000) hell hsum W hW hcompact hsupp
    (fun j y => (hWB j y).1) hne W0 W1 a0 b0 a1 b1 ha0 ha1
    hW0 hW1 hr0 hr1 hp0 hp1 hn0 hn1 hraw

#print candidate_normalized_low
#print axioms candidate_normalized_low

end
end QRHExtension.LowProof
