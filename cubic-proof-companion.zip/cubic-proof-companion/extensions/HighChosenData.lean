import HighChosenInput
import HighAssemblyFixed
import HighCommonProbe

namespace OAI

noncomputable section
open scoped Classical
open Filter

namespace SevenEighths.ProbeFinalAssembly.Extension
open HeckeFamily ProbePhysical ProbeHighRowFamily Parameters PrincipalSignalComparison
open Parameters.Extension

theorem common_probe_of_chosen_moments (hmom : ChosenMomentInput) : HeckeCommonProbe.Extension.UniformCommonProbe := by
  intro hβ
  obtain ⟨D,F,counts,J,hJ,hmom⟩:=hmom hβ
  obtain ⟨τ,hτ,hτd,hτcost,hτt,hτ2,hτeps,hsource⟩ := chosen_data_height D F counts J hJ hmom
  obtain ⟨C,hC,hhigh⟩ := fixed_high_bound hβ D F counts τ hτ hτd hτcost hτt hτ2 hτeps
  let loss := (HeckeZeroSupremum.beta-87499/100000)/2
  have hloss : 0<loss := by dsimp [loss];linarith
  have hlossgap : loss<HeckeZeroSupremum.beta-87499/100000 := by dsimp [loss];linarith
  refine ⟨loss,D.sigma,hloss,hlossgap,D.sigma_pos,?_⟩
  intro η hprimitive
  obtain ⟨hmask,hH,hHbound⟩ := actual_source_analytic F.S F.exclusions η
  refine ⟨η.excludePrimes F.S F.exclusions.prime,sourceCorrection η F.S,F.probe η,
    hmask,hH,hHbound,F.probe_low loss hloss η,?_⟩
  obtain ⟨Ct,hCt,hhigh⟩ := hhigh η
  obtain ⟨Cm,hCm,hsource⟩ := hsource η
  apply isBigO_rpow_of_eventual_norm_bound
  refine ⟨Ct+C*Cm*(η.modulus.absNorm:ℝ)^(2*D.eps),by positivity,?_⟩
  filter_upwards [hhigh,hsource] with Z hh hs
  exact hh Cm hCm.le hs

theorem dirichlet_of_chosen_moments (hmom : ChosenMomentInput) (q : ℕ) (hq : q≠0)
    (χ : DirichletCharacter ℂ q) (s : ℂ) (hs : (87499/100000:ℝ)<s.re)
    (hexc : ¬(χ=1 ∧ s=1)) :
    letI : NeZero q := ⟨hq⟩
    DirichletCharacter.LFunction χ s≠0 :=
  HeckeCommonProbe.Extension.dirichlet_of_common_probe (common_probe_of_chosen_moments hmom) q hq χ s hs hexc

theorem zeta_of_chosen_moments (hmom : ChosenMomentInput) (s : ℂ) (hs : (87499/100000:ℝ)<s.re) :
    riemannZeta s≠0 :=
  HeckeCommonProbe.Extension.zeta_of_common_probe (common_probe_of_chosen_moments hmom) s hs

theorem hecke_of_chosen_moments (hmom : ChosenMomentInput) (χ : Character) (s : ℂ)
    (hs : (87499/100000:ℝ)<s.re) (hpole : s≠1 ∨ χ.residue≠1) : LFunction χ s≠0 :=
  HeckeCommonProbe.Extension.hecke_ne_zero_of_common_probe (common_probe_of_chosen_moments hmom) χ s hs hpole

end SevenEighths.ProbeFinalAssembly.Extension

end

end OAI
