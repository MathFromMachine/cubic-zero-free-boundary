import HighCertified
import HighChosenData

namespace OAI

noncomputable section
open scoped Classical BigOperators SchwartzMap ComplexConjugate
open Filter

namespace SevenEighths.ProbeFinalAssemblyCertifiedBands.Extension
open HeckeFamily HeckeDyadic HeckeInverseAmplification HeckeDetectorRawFiber HeckeDetectorBatch
open ProbeFinalAssembly ProbeHighRowFamily Parameters
open CenteredMomentEnergyBands CenteredMomentEnergyState
open CenteredMomentEnergyCappedWidthInduction CenteredMomentEnergyWidthRanges
open CenteredMomentEnergyWidthSchedule CenteredMomentDetectorPlainMomentParameters
open CenteredMomentDetectorEnergyInitialState CenteredMomentNaturalFixedRaySource
open ProbeDetectorPlainMarkedFineField ProbeDetectorPlainUnmarkedField
open Parameters.Extension ProbeFinalAssembly.Extension ProbeHighRowFamily.Extension CenteredMomentDetectorPlainMomentParameters.Extension CenteredMomentDetectorEnergyInitialState.Extension CenteredMomentNaturalFixedRaySource.Extension ProbeDetectorPlainMarkedFineField.Extension ProbeDetectorPlainUnmarkedField.Extension
local notation "O"=>HeckeFamily.O

theorem dirichlet_of_certified (h:ProbeFinalAssemblyCertifiedBands.Extension.DetectorCertifiedBands)(q:ℕ)(hq:q≠0)
    (χ:DirichletCharacter ℂ q)(s:ℂ)(hs:(87499/100000:ℝ)<s.re)(hexc:¬(χ=1 ∧ s=1)):
    letI:NeZero q:=⟨hq⟩
    DirichletCharacter.LFunction χ s≠0:=
  ProbeFinalAssembly.Extension.dirichlet_of_chosen_moments (ProbeFinalAssemblyCertifiedBands.Extension.chosen_moments_of_certified h) q hq χ s hs hexc

theorem zeta_of_certified (h:ProbeFinalAssemblyCertifiedBands.Extension.DetectorCertifiedBands)(s:ℂ)(hs:(87499/100000:ℝ)<s.re):riemannZeta s≠0:=
  ProbeFinalAssembly.Extension.zeta_of_chosen_moments (ProbeFinalAssemblyCertifiedBands.Extension.chosen_moments_of_certified h) s hs

end SevenEighths.ProbeFinalAssemblyCertifiedBands.Extension

end

end OAI
namespace OAI

noncomputable section
open scoped Classical BigOperators SchwartzMap ContDiff ComplexConjugate

namespace SevenEighths.ProbeFinalAssemblyUnconditional.Extension
open ProbeFinalAssembly ProbeFinalAssemblyCertifiedBands
open CenteredMomentEnergyCertifiedExistence CenteredMomentDetectorPlainMomentParameters
open CenteredMomentDetectorPlainSlotProfile
open ProbeFinalAssembly.Extension ProbeFinalAssemblyCertifiedBands.Extension CenteredMomentDetectorPlainMomentParameters.Extension CenteredMomentDetectorPlainSlotProfile.Extension

theorem dirichlet_nonzero (q:ℕ)(hq:q≠0)(χ:DirichletCharacter ℂ q)(s:ℂ)
    (hs:(87499/100000:ℝ)<s.re)(hexc:¬(χ=1 ∧ s=1)):
    letI:NeZero q:=⟨hq⟩
    DirichletCharacter.LFunction χ s≠0:=
  ProbeFinalAssemblyCertifiedBands.Extension.dirichlet_of_certified ProbeFinalAssemblyUnconditional.Extension.detector_certified_bands q hq χ s hs hexc

theorem zeta_nonzero (s:ℂ)(hs:(87499/100000:ℝ)<s.re):riemannZeta s≠0:=
  ProbeFinalAssemblyCertifiedBands.Extension.zeta_of_certified ProbeFinalAssemblyUnconditional.Extension.detector_certified_bands s hs

end SevenEighths.ProbeFinalAssemblyUnconditional.Extension

end

end OAI

#print axioms OAI.SevenEighths.ProbeFinalAssemblyUnconditional.Extension.zeta_nonzero
#print axioms OAI.SevenEighths.ProbeFinalAssemblyUnconditional.Extension.dirichlet_nonzero
