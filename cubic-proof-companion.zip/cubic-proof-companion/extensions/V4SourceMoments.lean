import OAI.NumberTheory.DirichletL.PrimeRows.NonfloorDictionary
import KappaNonfloorCount
import V4Kappa

namespace OAI

noncomputable section
open scoped Classical BigOperators
namespace SevenEighths.V4ProbeHighRowFamily
open HeckeFamily HeckeInverseAmplification HeckeDetectorBatch HeckeDetectorRawFiber ProbeHighRowFamily
local notation "O" => HeckeFamily.O
variable (M : Ideal O) [NeZero M]
local instance : Finite (O ⧸ M) := Ring.HasFiniteQuotients.finiteQuotient (NeZero.ne M)
variable (H : Subgroup (O ⧸ M)ˣ) (hH : RayOrthogonality.globalUnits M≤H)

/-- The legacy Delta argument is retained only for the public assembly's
    call shape. Capacity is fixed explicitly at kappaActual in this adapter. -/
def cutoff (delta q : ℝ) : ℝ :=
  HeckeDetectorAdaptiveCutoffKappa.cutoff RHV4.kappaActual delta q

def adaptiveRowExponent (δ q _legacyDelta ε εm slotMesh ν : ℝ) : ℝ :=
  if δ≤5/6 then QRHExtension.KappaOptimization.countR RHV4.kappaActual δ (q/δ)+159*ε+εm+slotMesh+7*ν
  else 1-δ+78*ε+εm

def SourceMomentsAt {N : ℕ} (S : Finset (Ideal O)) (hS : ∀P∈S,Prime P)
    (η : Character) (rows : Finset FreeRow) (ell : Fin N→ℝ) (W : Fin N→ℝ→ℂ)
    (Z d a ε τ dmax b slotMesh binWidth : ℝ) (i : ℕ) (z : ℂ)
    (_legacyDelta c κ C height εm : ℝ) : Prop :=
  ∀q : ℝ,∀B : Batch M H (Sum Bool (RayQuotient.Characters M H)) (Fin N)
      (Z^d) a ε (cutoff (2*a-1) q) (Z^τ) ((Z^d)^(τ/(2*dmax))) i,
    B.rows⊆rows → B.data=sourceMomentData M H hH S hS η →
    B.reverse=sourceMomentReverse M H → B.slots=Finset.univ →
    B.widths=(fun j=>ell j/d) → B.profile=W → B.upper=(fun _=>b) → B.external=(fun _=>z) →
    B.mesh=slotMesh → B.binWidth=binWidth →
    (∀u∈B.rows,∀j,B.family u j=sourceDetectorFamily S hS η u (rayCubeFamily M H hH u) j) →
    ∀bin j J K,∀hne : (B.fiberRows bin j J K).Nonempty,
      Moments (B.fiber bin j J K hne) ((RHV4.kappaActual-3/4)/2) c κ C height εm

end SevenEighths.V4ProbeHighRowFamily

end

end OAI
