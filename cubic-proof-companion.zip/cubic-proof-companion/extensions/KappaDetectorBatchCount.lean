import OAI.NumberTheory.DirichletL.Hecke.DetectorBatch
import KappaDetectorCountFromMoments

namespace OAI

noncomputable section
open scoped Classical BigOperators ContDiff
open Set Filter
namespace SevenEighths.HeckeDetectorBatchCountKappa
open HeckeFamily HeckeDetectorRawFiber HeckeDetectorBatch HeckeDetectorWitnessRows HeckeDetectorRowCount

theorem batch_count_from_raw_moments
    (M : Ideal O) [NeZero M] (H : Subgroup (O ⧸ M)ˣ)
    (hH : RayOrthogonality.globalUnits M≤H) (S : Finset (Ideal O))
    (φ : ℝ→ℝ) (hφ : ContDiff ℝ ∞ φ) (hφc : HasCompactSupport φ)
    (hφp : tsupport φ⊆Ioi 0) (hφ0 : ∀ y,0≤φ y) (hφne : φ≠0)
    (a₀ b₀ B₀ : ℝ) (ha₀ : 0<a₀) (hab₀ : a₀≤b₀) (hB₀ : 0<B₀)
    (hφs : Function.support φ⊆Ioo a₀ b₀) (hφB : ∀ y,φ y≤B₀)
    (εm : ℝ) (hεm : 0<εm) :
    ∃ c κraw K₀ : ℝ,0<c ∧ c≤1 ∧ 0<κraw ∧ 0≤K₀ ∧ ∀ᶠ U : ℝ in atTop,
      ∀ (a ε tstar T allowance κ ν C height : ℝ) (i : ℕ),
      1<U → 51/100<a → 2*a-1≤5/6 → 0≤ε → ε≤1/1000 →
      1≤tstar → tstar≤3/2 → 2/3≤κ → κ≤3/4 → 0<ν → 0≤C → 0≤height →
      2*Real.pi*allowance+(3*i : ℕ)*T≤height →
      ∀ {Label Slot : Type*} [Fintype Label] (B : Batch M H Label Slot U a ε tstar T allowance i),
      (∀ bin j J K,∀ hne : (B.fiberRows bin j J K).Nonempty,
        Moments (B.fiber bin j J K hne) ((κ-3/4)/2) c κraw C height εm) →
      (B.rows.card : ℝ)≤(Fintype.card Label : ℝ)*(dyadicLength U : ℝ)^2* fiberConstant C height K₀*
        ∑ bin : B.Bin,U^(max (QRHExtension.KappaCounts.shortExponent κ (2*a-1) (B.q bin/(2*a-1)) tstar)
          (longExponent (2*a-1) tstar)+159*ε+εm+B.mesh+7*ν) := by
  obtain ⟨c,κraw,K₀,hc,hc1,hκraw,hK,hcount⟩ := HeckeDetectorCountFromMomentsKappa.count_from_raw_moments
    M H hH S φ hφ hφc hφp hφ0 hφne a₀ b₀ B₀ ha₀ hab₀ hB₀ hφs hφB εm hεm
  refine ⟨c,κraw,K₀,hc,hc1,hκraw,hK,?_⟩
  filter_upwards [hcount] with U hcount
  intro a ε tstar T allowance κ ν C height i hU ha hδcap hε hεsmall ht ht' hκ hκ' hν hC hh hf
    Label Slot _ B moments
  apply B.card_bound (fiberConstant C height K₀) _
    (fiberConstant_bounds C height K₀ hC hh hK).1 (zero_lt_one.trans hU)
  intro bin j J K hne
  exact hcount a ε tstar T allowance κ ν C height i hU ha hδcap hε hεsmall ht ht' hκ hκ' hν hC hh hf
    (B.fiber bin j J K hne) (moments bin j J K hne)

end SevenEighths.HeckeDetectorBatchCountKappa

end

end OAI
