import KappaReflectionRetainedLength
import KappaReferenceState
import KappaReferenceDivisors
import KappaReferenceDeletionCapacity
import KappaReferenceDeletionClipped
import KappaReferenceLowBranchGeometry
import KappaReferenceLowWindow
import KappaReferenceLowDeletedGeometry
import KappaOriginalHighReflectionGeometry
import KappaLiveClippingDefect
import KappaDeletedRobustGeometry
import KappaOriginalHighReflectionDeleted
import KappaReferenceRobustDeletedEnergy
import KappaOriginalHighReflectionOriginal
import KappaReferenceRobustOriginal
import KappaOriginalHighReflectionPower
import KappaReferenceRobustPower
import KappaOriginalHighReflectionSymmetric
import KappaOriginalHighReflectionBounded
import KappaReferenceLivePower
import KappaReferenceRobustBounded
import KappaReferenceLiveBounded
import KappaOriginalHighReflectionSymmetricBounded
import KappaPositiveHighSource
import KappaPositiveHighAssembly
import KappaPositiveHighSourceBounded
import KappaPositiveHighAssemblyBounded
import KappaPositiveHighParameters
import KappaPositiveBalancedAdmission
import KappaPositiveHighBound
import KappaPositiveHighSourceBound
import KappaFirstSourceParameters
import KappaNaturalLowPhysical
import KappaPositiveHighPhysical
import KappaNaturalHighStage
import KappaNaturalLowStage
import KappaCappedLowStage
import KappaZeroGrowthPhysical
import KappaNaturalZeroStage
import KappaCappedAnalyticSuccessor
import OAI.NumberTheory.DirichletL.Energy.CertifiedExistence
import KappaCappedAnalyticSuccessor
import OAI.NumberTheory.DirichletL.Energy.CappedRadialTransport

namespace OAI

noncomputable section
open scoped Classical BigOperators SchwartzMap ContDiff

namespace SevenEighths.CenteredMomentEnergyCertifiedExistenceKappa
open HeckeFamily CenteredMomentEnergyCappedWidthInduction
open CenteredMomentEnergyCappedAnalyticSuccessorKappa CenteredMomentEnergyCappedRadialTransport
open CenteredMomentEnergyWidthSchedule
local notation "O"=>HeckeFamily.O
variable {α:Type*}[Fintype α][DecidableEq α]
variable (M:Ideal O)[NeZero M]
local instance : Finite (O⧸M):=Ring.HasFiniteQuotients.finiteQuotient (NeZero.ne M)
variable (H:Subgroup (O⧸M)ˣ)(hH:RayOrthogonality.globalUnits M≤H)

theorem certified_bands (W:ℝ→ℂ)(aslot bslot a b radial Bmask L lo hi Mcap κ ε:ℝ)
    (haslot:0<aslot)(hWs:Function.support W⊆Set.Icc aslot bslot)(hW:ContDiff ℝ ∞ W)
    (hbslot:0≤bslot)(ha:0<a)(haUpper:a≤1/4)(hb:1≤b)(hrad:2≤radial)
    (hmask:0≤Bmask)(hMcap:0<Mcap)(hκ0:(13/18:ℝ)≤κ)(hε:0<ε)
    (hbeta:(51/100:ℝ)≤HeckeZeroSupremum.beta)(hκ:2*HeckeZeroSupremum.beta-1≤κ):
    ∀k:ℕ,k≤count Mcap ε→
      CertifiedBand (α:=α) M H hH W bslot a b radial Bmask L lo hi Mcap κ ε k:=by
  intro k
  induction k with
  | zero =>
    intro _
    exact certified_floor (α:=α) M H hH W aslot bslot a b radial Bmask L lo hi Mcap κ ε
      haslot hWs hW ha (by linarith) (by linarith) hmask hMcap.le (by linarith) hε hbeta hκ
  | succ k ih =>
    intro hk
    have hprevious:=ih (Nat.le_of_succ_le hk)
    have hstep:k<count Mcap ε:=by omega
    exact actual_successor (α:=α) M H hH W aslot bslot a b radial Bmask L lo hi Mcap κ ε
      haslot hWs hW hbslot ha haUpper hb hrad hmask hMcap hκ0 hε hbeta hκ
      k hstep hprevious

theorem terminal_certificate (W:ℝ→ℂ)(aslot bslot a b radial Bmask L lo hi Mcap κ ε:ℝ)
    (haslot:0<aslot)(hWs:Function.support W⊆Set.Icc aslot bslot)(hW:ContDiff ℝ ∞ W)
    (hbslot:0≤bslot)(ha:0<a)(haUpper:a≤1/4)(hb:1≤b)(_hrad:0<radial)
    (hmask:0≤Bmask)(hMcap:0<Mcap)(hκ0:(13/18:ℝ)≤κ)(hε:0<ε)
    (hbeta:(51/100:ℝ)≤HeckeZeroSupremum.beta)(hκ:2*HeckeZeroSupremum.beta-1≤κ):
    CertifiedBand (α:=α) M H hH W bslot a b radial Bmask L lo hi Mcap κ ε (count Mcap ε):=by
  apply certified_from_max_two (α:=α) M H hH W bslot a b radial Bmask L lo hi Mcap κ ε
  exact certified_bands (α:=α) M H hH W aslot bslot a b (max 2 radial) Bmask L lo hi Mcap κ ε
    haslot hWs hW hbslot ha haUpper hb (le_max_left _ _) hmask hMcap hκ0 hε hbeta hκ _ le_rfl

end SevenEighths.CenteredMomentEnergyCertifiedExistenceKappa

end

end OAI
