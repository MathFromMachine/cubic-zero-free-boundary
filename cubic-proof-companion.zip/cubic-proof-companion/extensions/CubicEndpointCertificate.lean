import CubicMethodLimit

/-! Proposed exact all-bin scalar certificate at the cubic method limit.
This concerns the explicit scalar exponent. It does not absorb analytic losses,
and it does not assert a zero-free theorem exactly at the limiting boundary. -/
namespace QRHExtension.KappaCubicEndpoint
noncomputable section
open QRHExtension.KappaOptimization QRHExtension.KappaMethodLimit

def endpointEll (B : ℝ) : ℝ := 11/3-4*B
def endpointH (B : ℝ) : ℝ :=
  (-5490196/245823:ℝ)
    + (4880924/81941:ℝ)*B
    + (-3101040/81941:ℝ)*B^2
def endpointC0 (B : ℝ) : ℝ := 7/3-3*B+endpointH B/3
def endpointExponent (B δ x : ℝ) : ℝ :=
  endpointC0 B+(1/2+endpointEll B)*δ+endpointEll B*x*δ-
    endpointH B*(1-countR (2*B-1) δ x)
private def certificate (B δ v : ℝ) : ℝ :=
  (8334844655/296462538:ℝ)
    + (-758280305/148231269:ℝ)*v
    + (-1050484706/49410423:ℝ)*δ
    + (-21786773429/98820846:ℝ)*δ*v
    + (5137034563/49410423:ℝ)*δ*v^2
    + (792194558/82350705:ℝ)*δ^2
    + (4590509266/27450235:ℝ)*δ^2*v
    + (-10597545206/27450235:ℝ)*δ^2*v^2
    + (18676/201:ℝ)*δ^2*v^3
    + (-8079795035/98820846:ℝ)*B
    + (-248549515/49410423:ℝ)*B*v
    + (1094205482/16470141:ℝ)*B*δ
    + (8033748964/16470141:ℝ)*B*δ*v
    + (-3824940376/16470141:ℝ)*B*δ*v^2
    + (-595264226/27450235:ℝ)*B*δ^2
    + (-9755423546/27450235:ℝ)*B*δ^2*v
    + (23722465936/27450235:ℝ)*B*δ^2*v^2
    + (-13224/67:ℝ)*B*δ^2*v^3
    + (935768020/16470141:ℝ)*B^2
    + (206160760/16470141:ℝ)*B^2*v
    + (-267035168/5490047:ℝ)*B^2*δ
    + (-1483750696/5490047:ℝ)*B^2*δ*v
    + (711327184/5490047:ℝ)*B^2*δ*v^2
    + (352390272/27450235:ℝ)*B^2*δ^2
    + (5196679032/27450235:ℝ)*B^2*δ^2*v
    + (-13238525472/27450235:ℝ)*B^2*δ^2*v^2
    + (7008/67:ℝ)*B^2*δ^2*v^3

private def quadraticLead (B v : ℝ) : ℝ :=
  (792194558/82350705:ℝ)
    + (4590509266/27450235:ℝ)*v
    + (-10597545206/27450235:ℝ)*v^2
    + (18676/201:ℝ)*v^3
    + (-595264226/27450235:ℝ)*B
    + (-9755423546/27450235:ℝ)*B*v
    + (23722465936/27450235:ℝ)*B*v^2
    + (-13224/67:ℝ)*B*v^3
    + (352390272/27450235:ℝ)*B^2
    + (5196679032/27450235:ℝ)*B^2*v
    + (-13238525472/27450235:ℝ)*B^2*v^2
    + (7008/67:ℝ)*B^2*v^3

private def quadraticMiddle (B v : ℝ) : ℝ :=
  (-1050484706/49410423:ℝ)
    + (-21786773429/98820846:ℝ)*v
    + (5137034563/49410423:ℝ)*v^2
    + (1094205482/16470141:ℝ)*B
    + (8033748964/16470141:ℝ)*B*v
    + (-3824940376/16470141:ℝ)*B*v^2
    + (-267035168/5490047:ℝ)*B^2
    + (-1483750696/5490047:ℝ)*B^2*v
    + (711327184/5490047:ℝ)*B^2*v^2

private def discriminantComplement (B v : ℝ) : ℝ :=
  (214721514764169070/813796633679643:ℝ)*v
    + (-10945366561053363761/1085062178239524:ℝ)*v^2
    + (9722405327253328853/813796633679643:ℝ)*v^3
    + (-2497429483672521683/813796633679643:ℝ)*v^4
    + (-165773535097714990/271265544559881:ℝ)*B*v
    + (2002967814784304648/90421848186627:ℝ)*B*v^2
    + (-7110404846871922816/271265544559881:ℝ)*B*v^3
    + (610951909205536592/90421848186627:ℝ)*B*v^4
    + (10665143071080120/30140616062209:ℝ)*B^2*v
    + (-1097745597213237956/90421848186627:ℝ)*B^2*v^2
    + (1297790395723347184/90421848186627:ℝ)*B^2*v^3
    + (-335781663787849424/90421848186627:ℝ)*B^2*v^4

private def clearingQuotient (B δ v : ℝ) : ℝ :=
  (-479870/148231269:ℝ)
    + (959740/148231269:ℝ)*v
    + (-4337672/49410423:ℝ)*δ
    + (11111396/49410423:ℝ)*δ*v
    + (-4872104/49410423:ℝ)*δ*v^2
    + (3939056/82350705:ℝ)*δ^2
    + (-21351764/82350705:ℝ)*δ^2*v
    + (30224944/82350705:ℝ)*δ^2*v^2
    + (-16/201:ℝ)*δ^2*v^3

private def squareQuotient (B v : ℝ) : ℝ :=
  (-8442520/49410423:ℝ)
    + (-1980649004697580/813796633679643:ℝ)*v
    + (1985439009694660/90421848186627:ℝ)*v^2
    + (-34603500613471520/2441389901038929:ℝ)*v^3
    + (6385923059925040/2441389901038929:ℝ)*v^4
    + (3457280/49410423:ℝ)*B
    + (1793546092985120/813796633679643:ℝ)*B*v
    + (-16573427072030672/813796633679643:ℝ)*B*v^2
    + (7190197285043648/813796633679643:ℝ)*B*v^3
    + (-397417802170816/271265544559881:ℝ)*B*v^4

private def criticalQuotient (B δ v : ℝ) : ℝ :=
  (77074466363/89679917745:ℝ)
    + (-242873954/2717573265:ℝ)*δ
    + (-225543643711/59786611830:ℝ)*B
    + (117463424/905857755:ℝ)*B*δ
    + (53409313682/9964435305:ℝ)*B^2
    + (-8574829952/3321478435:ℝ)*B^3

private def algebraicDelta (B : ℝ) : ℝ :=
  (401/22:ℝ)
    + (-1215/22:ℝ)*B
    + (438/11:ℝ)*B^2

private theorem cleared_identity (B δ x : ℝ)
    (hp : boundaryPolynomial B=0) (hk : 2*B-1 ≠ 0)
    (hJ : countJ (2*B-1) δ x ≠ 0) :
    2*countJ (2*B-1) δ x*(-endpointExponent B δ x)=certificate B δ (1/2-x) := by
  have hi : 3*(2*B-1)*(2*countJ (2*B-1) δ x*(-endpointExponent B δ x)-
      certificate B δ (1/2-x))=boundaryPolynomial B*clearingQuotient B δ (1/2-x) := by
    unfold endpointExponent countR
    field_simp [hJ]
    simp only [countJ,countD,countA,primeWeight,endpointC0,endpointH,endpointEll,
      certificate,boundaryPolynomial,clearingQuotient]
    field_simp [hk]
    ring
  rw [hp,zero_mul] at hi
  exact sub_eq_zero.mp ((mul_eq_zero.mp hi).resolve_left (mul_ne_zero (by norm_num) hk))

private theorem completed_square (B δ v : ℝ) (hp : boundaryPolynomial B=0) :
    4*quadraticLead B v*certificate B δ v=
      (2*quadraticLead B v*δ+quadraticMiddle B v)^2+discriminantComplement B v := by
  have hi : 4*quadraticLead B v*certificate B δ v-
      (2*quadraticLead B v*δ+quadraticMiddle B v)^2-discriminantComplement B v=
      boundaryPolynomial B*squareQuotient B v := by
    unfold quadraticLead certificate quadraticMiddle discriminantComplement
      boundaryPolynomial squareQuotient
    ring
  rw [hp,zero_mul] at hi
  linarith

private theorem critical_square (B δ : ℝ) (hp : boundaryPolynomial B=0) :
    certificate B δ 0=quadraticLead B 0*(δ-algebraicDelta B)^2 := by
  have hi : certificate B δ 0-quadraticLead B 0*(δ-algebraicDelta B)^2=
      boundaryPolynomial B*criticalQuotient B δ 0 := by
    unfold certificate quadraticLead algebraicDelta boundaryPolynomial criticalQuotient
    ring
  rw [hp,zero_mul] at hi
  linarith

private theorem squared_bracket (B : ℝ)
    (hl : (43747850971/50000000000:ℝ) ≤ B)
    (hu : B ≤ (874957019421/1000000000000:ℝ)) :
    (43747850971/50000000000:ℝ)^2 ≤ B^2 ∧
      B^2 ≤ (874957019421/1000000000000:ℝ)^2 := by
  have hp : 0 ≤ B := by linarith
  constructor <;> nlinarith

private theorem lead0_positive (B : ℝ)
    (hl : (43747850971/50000000000:ℝ) ≤ B)
    (hu : B ≤ (874957019421/1000000000000:ℝ)) :
    0 < (792194558/82350705:ℝ)
    + (-595264226/27450235:ℝ)*B
    + (352390272/27450235:ℝ)*B^2 := by
  obtain ⟨hslo,hshi⟩ := squared_bracket B hl hu
  nlinarith only [hl,hu,hslo,hshi]

private theorem lead1_positive (B : ℝ)
    (hl : (43747850971/50000000000:ℝ) ≤ B)
    (hu : B ≤ (874957019421/1000000000000:ℝ)) :
    0 < (4590509266/27450235:ℝ)
    + (-9755423546/27450235:ℝ)*B
    + (5196679032/27450235:ℝ)*B^2 := by
  obtain ⟨hslo,hshi⟩ := squared_bracket B hl hu
  nlinarith only [hl,hu,hslo,hshi]

private theorem lead2_positive (B : ℝ)
    (hl : (43747850971/50000000000:ℝ) ≤ B)
    (hu : B ≤ (874957019421/1000000000000:ℝ)) :
    0 < (-10597545206/27450235:ℝ)
    + (23722465936/27450235:ℝ)*B
    + (-13238525472/27450235:ℝ)*B^2 := by
  obtain ⟨hslo,hshi⟩ := squared_bracket B hl hu
  nlinarith only [hl,hu,hslo,hshi]

private theorem lead3_positive (B : ℝ)
    (hl : (43747850971/50000000000:ℝ) ≤ B)
    (hu : B ≤ (874957019421/1000000000000:ℝ)) :
    0 < (18676/201:ℝ)
    + (-13224/67:ℝ)*B
    + (7008/67:ℝ)*B^2 := by
  obtain ⟨hslo,hshi⟩ := squared_bracket B hl hu
  nlinarith only [hl,hu,hslo,hshi]

private theorem disc1_positive (B : ℝ)
    (hl : (43747850971/50000000000:ℝ) ≤ B)
    (hu : B ≤ (874957019421/1000000000000:ℝ)) :
    0 < (214721514764169070/813796633679643:ℝ)
    + (-165773535097714990/271265544559881:ℝ)*B
    + (10665143071080120/30140616062209:ℝ)*B^2 := by
  obtain ⟨hslo,hshi⟩ := squared_bracket B hl hu
  nlinarith only [hl,hu,hslo,hshi]

private theorem disc2_positive (B : ℝ)
    (hl : (43747850971/50000000000:ℝ) ≤ B)
    (hu : B ≤ (874957019421/1000000000000:ℝ)) :
    0 < (-10945366561053363761/1085062178239524:ℝ)
    + (2002967814784304648/90421848186627:ℝ)*B
    + (-1097745597213237956/90421848186627:ℝ)*B^2 := by
  obtain ⟨hslo,hshi⟩ := squared_bracket B hl hu
  nlinarith only [hl,hu,hslo,hshi]

private theorem disc3_positive (B : ℝ)
    (hl : (43747850971/50000000000:ℝ) ≤ B)
    (hu : B ≤ (874957019421/1000000000000:ℝ)) :
    0 < (9722405327253328853/813796633679643:ℝ)
    + (-7110404846871922816/271265544559881:ℝ)*B
    + (1297790395723347184/90421848186627:ℝ)*B^2 := by
  obtain ⟨hslo,hshi⟩ := squared_bracket B hl hu
  nlinarith only [hl,hu,hslo,hshi]

private theorem disc4_positive (B : ℝ)
    (hl : (43747850971/50000000000:ℝ) ≤ B)
    (hu : B ≤ (874957019421/1000000000000:ℝ)) :
    0 < (-2497429483672521683/813796633679643:ℝ)
    + (610951909205536592/90421848186627:ℝ)*B
    + (-335781663787849424/90421848186627:ℝ)*B^2 := by
  obtain ⟨hslo,hshi⟩ := squared_bracket B hl hu
  nlinarith only [hl,hu,hslo,hshi]

private theorem lead_positive (v : ℝ) (hv : 0 ≤ v) :
    0 < quadraticLead methodLimit v := by
  have hl := methodLimit_bracket.1.le
  have hu := methodLimit_bracket.2.le
  have h0 := lead0_positive methodLimit hl hu
  have h1 := lead1_positive methodLimit hl hu
  have h2 := lead2_positive methodLimit hl hu
  have h3 := lead3_positive methodLimit hl hu
  have hi : quadraticLead methodLimit v =
    ((792194558/82350705:ℝ)
    + (-595264226/27450235:ℝ)*methodLimit
    + (352390272/27450235:ℝ)*methodLimit^2) +
    ((4590509266/27450235:ℝ)
    + (-9755423546/27450235:ℝ)*methodLimit
    + (5196679032/27450235:ℝ)*methodLimit^2)*v +
    ((-10597545206/27450235:ℝ)
    + (23722465936/27450235:ℝ)*methodLimit
    + (-13238525472/27450235:ℝ)*methodLimit^2)*v^2 +
    ((18676/201:ℝ)
    + (-13224/67:ℝ)*methodLimit
    + (7008/67:ℝ)*methodLimit^2)*v^3 := by unfold quadraticLead; ring
  rw [hi]
  positivity

private theorem discriminant_nonnegative (v : ℝ) (hv : 0 ≤ v) :
    0 ≤ discriminantComplement methodLimit v := by
  have hl := methodLimit_bracket.1.le
  have hu := methodLimit_bracket.2.le
  have h1 := disc1_positive methodLimit hl hu
  have h2 := disc2_positive methodLimit hl hu
  have h3 := disc3_positive methodLimit hl hu
  have h4 := disc4_positive methodLimit hl hu
  have hi : discriminantComplement methodLimit v =
    ((214721514764169070/813796633679643:ℝ)
    + (-165773535097714990/271265544559881:ℝ)*methodLimit
    + (10665143071080120/30140616062209:ℝ)*methodLimit^2)*v +
    ((-10945366561053363761/1085062178239524:ℝ)
    + (2002967814784304648/90421848186627:ℝ)*methodLimit
    + (-1097745597213237956/90421848186627:ℝ)*methodLimit^2)*v^2 +
    ((9722405327253328853/813796633679643:ℝ)
    + (-7110404846871922816/271265544559881:ℝ)*methodLimit
    + (1297790395723347184/90421848186627:ℝ)*methodLimit^2)*v^3 +
    ((-2497429483672521683/813796633679643:ℝ)
    + (610951909205536592/90421848186627:ℝ)*methodLimit
    + (-335781663787849424/90421848186627:ℝ)*methodLimit^2)*v^4 := by unfold discriminantComplement; ring
  rw [hi]
  positivity

private theorem discriminant_positive (v : ℝ) (hv : 0 < v) :
    0 < discriminantComplement methodLimit v := by
  have hl := methodLimit_bracket.1.le
  have hu := methodLimit_bracket.2.le
  have h1 := disc1_positive methodLimit hl hu
  have h2 := disc2_positive methodLimit hl hu
  have h3 := disc3_positive methodLimit hl hu
  have h4 := disc4_positive methodLimit hl hu
  have hi : discriminantComplement methodLimit v =
    ((214721514764169070/813796633679643:ℝ)
    + (-165773535097714990/271265544559881:ℝ)*methodLimit
    + (10665143071080120/30140616062209:ℝ)*methodLimit^2)*v +
    ((-10945366561053363761/1085062178239524:ℝ)
    + (2002967814784304648/90421848186627:ℝ)*methodLimit
    + (-1097745597213237956/90421848186627:ℝ)*methodLimit^2)*v^2 +
    ((9722405327253328853/813796633679643:ℝ)
    + (-7110404846871922816/271265544559881:ℝ)*methodLimit
    + (1297790395723347184/90421848186627:ℝ)*methodLimit^2)*v^3 +
    ((-2497429483672521683/813796633679643:ℝ)
    + (610951909205536592/90421848186627:ℝ)*methodLimit
    + (-335781663787849424/90421848186627:ℝ)*methodLimit^2)*v^4 := by unfold discriminantComplement; ring
  rw [hi]
  positivity

private theorem certificate_nonnegative (δ v : ℝ) (hv : 0 ≤ v) :
    0 ≤ certificate methodLimit δ v := by
  have ha := lead_positive v hv
  have hd := discriminant_nonnegative v hv
  have hi := completed_square methodLimit δ v methodLimit_spec.2
  have hs := sq_nonneg (2*quadraticLead methodLimit v*δ+quadraticMiddle methodLimit v)
  have hn : 0 ≤ 4*quadraticLead methodLimit v*certificate methodLimit δ v := by linarith
  exact nonneg_of_mul_nonneg_right hn (by positivity)

/-- Every scalar bin lies below the cubic limiting boundary. -/
theorem all_bins_nonpositive (δ x : ℝ)
    (hd0 : 0 ≤ δ) (hd1 : δ ≤ 5/6) (hx0 : 0 ≤ x) (hx1 : x ≤ 1/2) :
    endpointExponent methodLimit δ x ≤ 0 := by
  have hk : (2/3:ℝ) ≤ 2*methodLimit-1 := by
    have hh := methodLimit_spec.1.1
    linarith
  have hkp : 0 < 2*methodLimit-1 := by linarith
  have hJ := (generalized_countJ_bounds (2*methodLimit-1) δ x hk hd0 hd1 hx0 hx1).1
  have hi := cleared_identity methodLimit δ x methodLimit_spec.2 hkp.ne' hJ.ne'
  have hq := certificate_nonnegative δ (1/2-x) (by linarith)
  have hn : 0 ≤ -endpointExponent methodLimit δ x := by
    apply nonneg_of_mul_nonneg_right (a := 2*countJ (2*methodLimit-1) δ x)
    · rw [hi]
      exact hq
    · positivity
  linarith

/-- The scalar bound is attained at the critical bin; it has no uniform strict reserve. -/
theorem critical_bin_zero :
    endpointExponent methodLimit (criticalDelta methodLimit) (1/2)=0 := by
  have hB1 : 1-methodLimit ≠ 0 := by
    have hh := methodLimit_spec.1.2
    linarith
  unfold endpointExponent
  rw [methodLimit_critical_count]
  unfold endpointC0 endpointEll criticalDelta
  field_simp [hB1]
  ring


private theorem algebraicDelta_eq_critical (B : ℝ)
    (hp : boundaryPolynomial B=0) (hB : 1-B ≠ 0) :
    algebraicDelta B=criticalDelta B := by
  have hi : 18*(1-B)*algebraicDelta B-(9*B-7) = -boundaryPolynomial B/11 := by
    unfold algebraicDelta boundaryPolynomial
    ring
  rw [hp] at hi
  unfold criticalDelta
  apply (eq_div_iff (mul_ne_zero (by norm_num) hB)).2
  linarith

/-- The unique zero is the critical bin at the maximal prime amplitude. -/
theorem exponent_eq_zero_iff (δ x : ℝ)
    (hd0 : 0 ≤ δ) (hd1 : δ ≤ 5/6) (hx0 : 0 ≤ x) (hx1 : x ≤ 1/2) :
    endpointExponent methodLimit δ x=0 ↔ x=1/2 ∧ δ=criticalDelta methodLimit := by
  constructor
  · intro hE
    have hk : (2/3:ℝ) ≤ 2*methodLimit-1 := by
      have hh := methodLimit_spec.1.1
      linarith
    have hkp : 0 < 2*methodLimit-1 := by linarith
    have hJ := (generalized_countJ_bounds (2*methodLimit-1) δ x hk hd0 hd1 hx0 hx1).1
    have hi := cleared_identity methodLimit δ x methodLimit_spec.2 hkp.ne' hJ.ne'
    rw [hE,neg_zero,mul_zero] at hi
    have hQ : certificate methodLimit δ (1/2-x)=0 := hi.symm
    have hv : 0 ≤ 1/2-x := by linarith
    have hv0 : 1/2-x=0 := by
      by_contra hn
      have hvp : 0 < 1/2-x := lt_of_le_of_ne hv (Ne.symm hn)
      have hd := discriminant_positive (1/2-x) hvp
      have hs := sq_nonneg (2*quadraticLead methodLimit (1/2-x)*δ+
        quadraticMiddle methodLimit (1/2-x))
      have hc := completed_square methodLimit δ (1/2-x) methodLimit_spec.2
      rw [hQ,mul_zero] at hc
      linarith
    have hx : x=1/2 := by linarith
    have hQ0 : certificate methodLimit δ 0=0 := by simpa only [hv0] using hQ
    have hs := critical_square methodLimit δ methodLimit_spec.2
    rw [hQ0] at hs
    have ha := lead_positive 0 (by norm_num)
    have hz : (δ-algebraicDelta methodLimit)^2=0 :=
      (mul_eq_zero.mp hs.symm).resolve_left ha.ne'
    have hδ : δ=algebraicDelta methodLimit := sub_eq_zero.mp (sq_eq_zero_iff.mp hz)
    have hB1 : 1-methodLimit ≠ 0 := by
      have hh := methodLimit_spec.1.2
      linarith
    exact ⟨hx,hδ.trans (algebraicDelta_eq_critical methodLimit methodLimit_spec.2 hB1)⟩
  · rintro ⟨rfl,rfl⟩
    exact critical_bin_zero

/-- Every other bin has strict negativity, though no uniform margin exists at the cusp. -/
theorem exponent_negative_off_critical (δ x : ℝ)
    (hd0 : 0 ≤ δ) (hd1 : δ ≤ 5/6) (hx0 : 0 ≤ x) (hx1 : x ≤ 1/2)
    (hne : x ≠ 1/2 ∨ δ ≠ criticalDelta methodLimit) :
    endpointExponent methodLimit δ x < 0 := by
  have hle := all_bins_nonpositive δ x hd0 hd1 hx0 hx1
  apply lt_of_le_of_ne hle
  intro heq
  have hz := (exponent_eq_zero_iff δ x hd0 hd1 hx0 hx1).1 heq
  rcases hne with h|h
  · exact h hz.1
  · exact h hz.2

#print axioms all_bins_nonpositive
#print axioms critical_bin_zero
#print axioms exponent_eq_zero_iff
#print axioms exponent_negative_off_critical
end
end QRHExtension.KappaCubicEndpoint
