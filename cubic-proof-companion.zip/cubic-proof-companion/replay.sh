#!/usr/bin/env bash
set -euo pipefail
: "${PUBLIC_PROOF_WORK:?Set PUBLIC_PROOF_WORK to the reconstructed build directory}"
export QRH_CANDIDATE_AUDIT="$PUBLIC_PROOF_WORK/audit"
export PUBLIC_PROOF_ROOT="$PUBLIC_PROOF_WORK/project/proof"
export PUBLIC_COMPARATOR_LIB="$PUBLIC_PROOF_WORK/tools/comparator/.lake/build/lib/lean"
export PUBLIC_EXPORT_LIB="$PUBLIC_PROOF_WORK/tools/comparator/.lake/packages/lean4export/.lake/build/lib/lean"
PUBLIC_COMPANION_ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
export COMPARATOR_LANDRUN="$PUBLIC_COMPANION_ROOT/landrun-wrapper.sh"
export COMPARATOR_LEAN4EXPORT="$PUBLIC_PROOF_WORK/tools/comparator/.lake/packages/lean4export/.lake/build/bin/lean4export"
export LEAN_NUM_THREADS=4
cd -- "$PUBLIC_PROOF_WORK/project"
mkdir -p -- "$PUBLIC_PROOF_WORK/.lake"
lake env bash -c '
  export LEAN_PATH="$QRH_CANDIDATE_AUDIT:$LEAN_PATH"
  exec lean -j 4 --root="$QRH_CANDIDATE_AUDIT" \
    -o "$QRH_CANDIDATE_AUDIT/V4Challenge.olean" "$QRH_CANDIDATE_AUDIT/V4Challenge.lean"
'
lake env bash -c '
  export LEAN_PATH="$PUBLIC_PROOF_ROOT:$QRH_CANDIDATE_AUDIT:$PUBLIC_COMPARATOR_LIB:$PUBLIC_EXPORT_LIB:$LEAN_PATH"
  IFS=: read -r -a entries <<< "$LEAN_PATH"
  absolute=
  for entry in "${entries[@]}"; do
    case "$entry" in /*) ;; *) entry="$PWD/$entry" ;; esac
    absolute="${absolute:+$absolute:}$entry"
  done
  export LEAN_PATH="$absolute"
  cd -- "$PUBLIC_PROOF_WORK"
  exec lean -j 4 "$QRH_CANDIDATE_AUDIT/ReplayCandidate.lean"
'
