import Main

/-!
Use the already built, pinned Comparator implementation without its Lake-build
step. V4CandidateTheorem is compiled by the serial extension build, and the
Mathlib-only challenge is freshly compiled by the audit launcher. All export,
statement/definition comparison, axiom checking, quotient checks, and fresh
Lean-kernel replay below use the original Comparator implementation.
-/
namespace QRHV4Audit

def replay : IO Unit := do
  let some auditDir ← IO.getEnv "QRH_CANDIDATE_AUDIT"
    | throw <| IO.userError "QRH_CANDIDATE_AUDIT is required"
  let auditPath : System.FilePath := auditDir
  let configText ← IO.FS.readFile (auditPath / "candidate-comparator.json")
  let configJson ← IO.ofExcept (Lean.Json.parse configText)
  let config : Comparator.Config ← IO.ofExcept (Lean.FromJson.fromJson? configJson)
  Comparator.M.run (do
    let targets := (← Comparator.builtinTargets) ++ (← Comparator.getTheoremNames) ++
      (← Comparator.getLegalAxioms) ++ (← Comparator.primitiveTargets) ++
      (← Comparator.getDefinitionNames)
    let challenge ← Comparator.safeExport (← Comparator.getChallengeModule) targets
    IO.FS.writeFile (auditPath / "challenge.export") challenge
    let solution ← Comparator.safeExport (← Comparator.getSolutionModule) targets
    IO.FS.writeFile (auditPath / "solution.export") solution
    Comparator.verifyMatch challenge solution
    IO.println "CANDIDATE_COMPARATOR_SUCCESS: the exact endpoint theorem statements, recursive definitions, permitted axioms, and fresh Lean-kernel replay accepted."
  ) config

end QRHV4Audit

#eval QRHV4Audit.replay
