#!/bin/sh
# Retain the original audit's four-thread limit inside Landrun's child environment.
: "${PUBLIC_PROOF_WORK:?PUBLIC_PROOF_WORK is required}"
exec "$PUBLIC_PROOF_WORK/tools/landrun/landrun" --env LEAN_NUM_THREADS=4 "$@"
